<?php
	$Alamat = "Jln. xxxteen.com";
	$dir = "....................";
?>