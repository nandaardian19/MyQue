<?php
	$id_admin=$_SESSION['id_admin'];
	$query=mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM user_admin WHERE id_admin='$id_admin'");
	$ran=mysqli_fetch_array($query);

?>
