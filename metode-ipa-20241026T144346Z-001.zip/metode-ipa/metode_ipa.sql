-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 28, 2022 at 09:17 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `metode_ipa`
--

-- --------------------------------------------------------

--
-- Table structure for table `cover`
--

CREATE TABLE `cover` (
  `id_cover` int(3) NOT NULL,
  `judul` varchar(50) NOT NULL,
  `foto` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cover`
--

INSERT INTO `cover` (`id_cover`, `judul`, `foto`) VALUES
(1, 'Selamat Datang., di Halaman Admin', '001.jpg'),
(2, 'Metode Importance Performance Analysis (IPA)', '002.jpg'),
(3, 'Aplikasi Survey Kepuasan Pelanggan', '003.jpg'),
(4, 'Analisis Metode IPA', '004.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `dimensi`
--

CREATE TABLE `dimensi` (
  `id_dimensi` int(11) NOT NULL,
  `nama_dimensi` varchar(50) NOT NULL,
  `tgl_input` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dimensi`
--

INSERT INTO `dimensi` (`id_dimensi`, `nama_dimensi`, `tgl_input`) VALUES
(1, 'Empathy (Perhatian)', '2021-09-04 00:46:34'),
(2, 'Tangibles (Bukti Nyata)', '2021-09-04 00:46:52'),
(3, 'Responsive (Ketanggapan)', '2021-09-04 00:46:57'),
(4, 'Reliability (Kehandalan)', '2021-09-04 00:47:02'),
(6, 'Assurance (Jaminan)', '2021-09-04 07:25:59');

-- --------------------------------------------------------

--
-- Table structure for table `nilai_harapan`
--

CREATE TABLE `nilai_harapan` (
  `id` int(11) NOT NULL,
  `id_variabel` int(11) NOT NULL,
  `id_dimensi` int(11) NOT NULL,
  `id_survey` varchar(20) NOT NULL,
  `nilai_harapan` char(1) NOT NULL,
  `h1` int(1) NOT NULL,
  `h2` int(1) NOT NULL,
  `h3` int(1) NOT NULL,
  `h4` int(1) NOT NULL,
  `h5` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 PACK_KEYS=0;

--
-- Dumping data for table `nilai_harapan`
--

INSERT INTO `nilai_harapan` (`id`, `id_variabel`, `id_dimensi`, `id_survey`, `nilai_harapan`, `h1`, `h2`, `h3`, `h4`, `h5`) VALUES
(1, 29, 1, '20220528 103337', '5', 5, 0, 0, 0, 0),
(2, 9, 1, '20220528 103337', '5', 5, 0, 0, 0, 0),
(3, 2, 1, '20220528 103337', '4', 0, 4, 0, 0, 0),
(4, 34, 1, '20220528 103337', '5', 5, 0, 0, 0, 0),
(5, 32, 1, '20220528 103337', '3', 0, 0, 3, 0, 0),
(6, 30, 1, '20220528 103337', '4', 0, 4, 0, 0, 0),
(7, 10, 1, '20220528 103337', '5', 5, 0, 0, 0, 0),
(8, 7, 1, '20220528 103337', '5', 5, 0, 0, 0, 0),
(9, 33, 1, '20220528 103337', '4', 0, 4, 0, 0, 0),
(10, 31, 1, '20220528 103337', '5', 5, 0, 0, 0, 0),
(11, 12, 2, '20220528 103337', '5', 5, 0, 0, 0, 0),
(12, 8, 2, '20220528 103337', '5', 5, 0, 0, 0, 0),
(13, 1, 2, '20220528 103337', '4', 0, 4, 0, 0, 0),
(14, 40, 2, '20220528 103337', '5', 5, 0, 0, 0, 0),
(15, 38, 2, '20220528 103337', '5', 5, 0, 0, 0, 0),
(16, 25, 2, '20220528 103337', '4', 0, 4, 0, 0, 0),
(17, 11, 2, '20220528 103337', '4', 0, 4, 0, 0, 0),
(18, 6, 2, '20220528 103337', '5', 5, 0, 0, 0, 0),
(19, 39, 2, '20220528 103337', '4', 0, 4, 0, 0, 0),
(20, 27, 2, '20220528 103337', '4', 0, 4, 0, 0, 0),
(21, 26, 3, '20220528 103337', '3', 0, 0, 3, 0, 0),
(22, 14, 3, '20220528 103337', '4', 0, 4, 0, 0, 0),
(23, 3, 3, '20220528 103337', '3', 0, 0, 3, 0, 0),
(24, 35, 3, '20220528 103337', '4', 0, 4, 0, 0, 0),
(25, 15, 3, '20220528 103337', '5', 5, 0, 0, 0, 0),
(26, 13, 3, '20220528 103337', '5', 5, 0, 0, 0, 0),
(27, 37, 3, '20220528 103337', '4', 0, 4, 0, 0, 0),
(28, 19, 4, '20220528 103337', '4', 0, 4, 0, 0, 0),
(29, 17, 4, '20220528 103337', '1', 0, 0, 0, 0, 1),
(30, 4, 4, '20220528 103337', '3', 0, 0, 3, 0, 0),
(31, 36, 4, '20220528 103337', '2', 0, 0, 0, 2, 0),
(32, 18, 4, '20220528 103337', '5', 5, 0, 0, 0, 0),
(33, 16, 4, '20220528 103337', '4', 0, 4, 0, 0, 0),
(34, 23, 6, '20220528 103337', '5', 5, 0, 0, 0, 0),
(35, 21, 6, '20220528 103337', '4', 0, 4, 0, 0, 0),
(36, 5, 6, '20220528 103337', '5', 5, 0, 0, 0, 0),
(37, 24, 6, '20220528 103337', '4', 0, 4, 0, 0, 0),
(38, 22, 6, '20220528 103337', '5', 5, 0, 0, 0, 0),
(39, 20, 6, '20220528 103337', '4', 0, 4, 0, 0, 0),
(40, 28, 6, '20220528 103337', '5', 5, 0, 0, 0, 0),
(41, 29, 1, '20220528 105638', '5', 5, 0, 0, 0, 0),
(42, 9, 1, '20220528 105638', '4', 0, 4, 0, 0, 0),
(43, 2, 1, '20220528 105638', '4', 0, 4, 0, 0, 0),
(44, 34, 1, '20220528 105638', '4', 0, 4, 0, 0, 0),
(45, 32, 1, '20220528 105638', '3', 0, 0, 3, 0, 0),
(46, 30, 1, '20220528 105638', '4', 0, 4, 0, 0, 0),
(47, 10, 1, '20220528 105638', '4', 0, 4, 0, 0, 0),
(48, 7, 1, '20220528 105638', '5', 5, 0, 0, 0, 0),
(49, 33, 1, '20220528 105638', '5', 5, 0, 0, 0, 0),
(50, 31, 1, '20220528 105638', '4', 0, 4, 0, 0, 0),
(51, 12, 2, '20220528 105638', '4', 0, 4, 0, 0, 0),
(52, 8, 2, '20220528 105638', '4', 0, 4, 0, 0, 0),
(53, 1, 2, '20220528 105638', '5', 5, 0, 0, 0, 0),
(54, 40, 2, '20220528 105638', '4', 0, 4, 0, 0, 0),
(55, 38, 2, '20220528 105638', '5', 5, 0, 0, 0, 0),
(56, 25, 2, '20220528 105638', '4', 0, 4, 0, 0, 0),
(57, 11, 2, '20220528 105638', '5', 5, 0, 0, 0, 0),
(58, 6, 2, '20220528 105638', '5', 5, 0, 0, 0, 0),
(59, 39, 2, '20220528 105638', '3', 0, 0, 3, 0, 0),
(60, 27, 2, '20220528 105638', '3', 0, 0, 3, 0, 0),
(61, 26, 3, '20220528 105638', '4', 0, 4, 0, 0, 0),
(62, 14, 3, '20220528 105638', '5', 5, 0, 0, 0, 0),
(63, 3, 3, '20220528 105638', '5', 5, 0, 0, 0, 0),
(64, 35, 3, '20220528 105638', '5', 5, 0, 0, 0, 0),
(65, 15, 3, '20220528 105638', '4', 0, 4, 0, 0, 0),
(66, 13, 3, '20220528 105638', '5', 5, 0, 0, 0, 0),
(67, 37, 3, '20220528 105638', '5', 5, 0, 0, 0, 0),
(68, 19, 4, '20220528 105638', '3', 0, 0, 3, 0, 0),
(69, 17, 4, '20220528 105638', '3', 0, 0, 3, 0, 0),
(70, 4, 4, '20220528 105638', '4', 0, 4, 0, 0, 0),
(71, 36, 4, '20220528 105638', '5', 5, 0, 0, 0, 0),
(72, 18, 4, '20220528 105638', '2', 0, 0, 0, 2, 0),
(73, 16, 4, '20220528 105638', '2', 0, 0, 0, 2, 0),
(74, 23, 6, '20220528 105638', '4', 0, 4, 0, 0, 0),
(75, 21, 6, '20220528 105638', '5', 5, 0, 0, 0, 0),
(76, 5, 6, '20220528 105638', '4', 0, 4, 0, 0, 0),
(77, 24, 6, '20220528 105638', '4', 0, 4, 0, 0, 0),
(78, 22, 6, '20220528 105638', '5', 5, 0, 0, 0, 0),
(79, 20, 6, '20220528 105638', '5', 5, 0, 0, 0, 0),
(80, 28, 6, '20220528 105638', '4', 0, 4, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `nilai_variabel`
--

CREATE TABLE `nilai_variabel` (
  `id` int(11) NOT NULL,
  `id_variabel` int(11) NOT NULL,
  `id_dimensi` int(11) NOT NULL,
  `id_survey` varchar(20) NOT NULL,
  `nilai_kinerja` char(1) NOT NULL,
  `skala1` int(1) NOT NULL,
  `skala2` int(1) NOT NULL,
  `skala3` int(1) NOT NULL,
  `skala4` int(1) NOT NULL,
  `skala5` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 PACK_KEYS=0;

--
-- Dumping data for table `nilai_variabel`
--

INSERT INTO `nilai_variabel` (`id`, `id_variabel`, `id_dimensi`, `id_survey`, `nilai_kinerja`, `skala1`, `skala2`, `skala3`, `skala4`, `skala5`) VALUES
(1, 29, 1, '20220528 103337', '4', 0, 4, 0, 0, 0),
(2, 9, 1, '20220528 103337', '2', 0, 0, 0, 2, 0),
(3, 2, 1, '20220528 103337', '3', 0, 0, 3, 0, 0),
(4, 34, 1, '20220528 103337', '1', 0, 0, 0, 0, 1),
(5, 32, 1, '20220528 103337', '2', 0, 0, 0, 2, 0),
(6, 30, 1, '20220528 103337', '3', 0, 0, 3, 0, 0),
(7, 10, 1, '20220528 103337', '1', 0, 0, 0, 0, 1),
(8, 7, 1, '20220528 103337', '2', 0, 0, 0, 2, 0),
(9, 33, 1, '20220528 103337', '4', 0, 4, 0, 0, 0),
(10, 31, 1, '20220528 103337', '3', 0, 0, 3, 0, 0),
(11, 12, 2, '20220528 103337', '5', 5, 0, 0, 0, 0),
(12, 8, 2, '20220528 103337', '4', 0, 4, 0, 0, 0),
(13, 1, 2, '20220528 103337', '4', 0, 4, 0, 0, 0),
(14, 40, 2, '20220528 103337', '4', 0, 4, 0, 0, 0),
(15, 38, 2, '20220528 103337', '1', 0, 0, 0, 0, 1),
(16, 25, 2, '20220528 103337', '2', 0, 0, 0, 2, 0),
(17, 11, 2, '20220528 103337', '2', 0, 0, 0, 2, 0),
(18, 6, 2, '20220528 103337', '4', 0, 4, 0, 0, 0),
(19, 39, 2, '20220528 103337', '5', 5, 0, 0, 0, 0),
(20, 27, 2, '20220528 103337', '3', 0, 0, 3, 0, 0),
(21, 26, 3, '20220528 103337', '2', 0, 0, 0, 2, 0),
(22, 14, 3, '20220528 103337', '4', 0, 4, 0, 0, 0),
(23, 3, 3, '20220528 103337', '3', 0, 0, 3, 0, 0),
(24, 35, 3, '20220528 103337', '2', 0, 0, 0, 2, 0),
(25, 15, 3, '20220528 103337', '4', 0, 4, 0, 0, 0),
(26, 13, 3, '20220528 103337', '4', 0, 4, 0, 0, 0),
(27, 37, 3, '20220528 103337', '3', 0, 0, 3, 0, 0),
(28, 19, 4, '20220528 103337', '4', 0, 4, 0, 0, 0),
(29, 17, 4, '20220528 103337', '3', 0, 0, 3, 0, 0),
(30, 4, 4, '20220528 103337', '4', 0, 4, 0, 0, 0),
(31, 36, 4, '20220528 103337', '2', 0, 0, 0, 2, 0),
(32, 18, 4, '20220528 103337', '3', 0, 0, 3, 0, 0),
(33, 16, 4, '20220528 103337', '3', 0, 0, 3, 0, 0),
(34, 23, 6, '20220528 103337', '4', 0, 4, 0, 0, 0),
(35, 21, 6, '20220528 103337', '3', 0, 0, 3, 0, 0),
(36, 5, 6, '20220528 103337', '2', 0, 0, 0, 2, 0),
(37, 24, 6, '20220528 103337', '1', 0, 0, 0, 0, 1),
(38, 22, 6, '20220528 103337', '2', 0, 0, 0, 2, 0),
(39, 20, 6, '20220528 103337', '1', 0, 0, 0, 0, 1),
(40, 28, 6, '20220528 103337', '3', 0, 0, 3, 0, 0),
(41, 29, 1, '20220528 105638', '5', 5, 0, 0, 0, 0),
(42, 9, 1, '20220528 105638', '2', 0, 0, 0, 2, 0),
(43, 2, 1, '20220528 105638', '4', 0, 4, 0, 0, 0),
(44, 34, 1, '20220528 105638', '2', 0, 0, 0, 2, 0),
(45, 32, 1, '20220528 105638', '3', 0, 0, 3, 0, 0),
(46, 30, 1, '20220528 105638', '5', 5, 0, 0, 0, 0),
(47, 10, 1, '20220528 105638', '4', 0, 4, 0, 0, 0),
(48, 7, 1, '20220528 105638', '2', 0, 0, 0, 2, 0),
(49, 33, 1, '20220528 105638', '2', 0, 0, 0, 2, 0),
(50, 31, 1, '20220528 105638', '3', 0, 0, 3, 0, 0),
(51, 12, 2, '20220528 105638', '4', 0, 4, 0, 0, 0),
(52, 8, 2, '20220528 105638', '4', 0, 4, 0, 0, 0),
(53, 1, 2, '20220528 105638', '3', 0, 0, 3, 0, 0),
(54, 40, 2, '20220528 105638', '4', 0, 4, 0, 0, 0),
(55, 38, 2, '20220528 105638', '1', 0, 0, 0, 0, 1),
(56, 25, 2, '20220528 105638', '2', 0, 0, 0, 2, 0),
(57, 11, 2, '20220528 105638', '3', 0, 0, 3, 0, 0),
(58, 6, 2, '20220528 105638', '2', 0, 0, 0, 2, 0),
(59, 39, 2, '20220528 105638', '5', 5, 0, 0, 0, 0),
(60, 27, 2, '20220528 105638', '5', 5, 0, 0, 0, 0),
(61, 26, 3, '20220528 105638', '2', 0, 0, 0, 2, 0),
(62, 14, 3, '20220528 105638', '4', 0, 4, 0, 0, 0),
(63, 3, 3, '20220528 105638', '4', 0, 4, 0, 0, 0),
(64, 35, 3, '20220528 105638', '2', 0, 0, 0, 2, 0),
(65, 15, 3, '20220528 105638', '3', 0, 0, 3, 0, 0),
(66, 13, 3, '20220528 105638', '2', 0, 0, 0, 2, 0),
(67, 37, 3, '20220528 105638', '4', 0, 4, 0, 0, 0),
(68, 19, 4, '20220528 105638', '4', 0, 4, 0, 0, 0),
(69, 17, 4, '20220528 105638', '4', 0, 4, 0, 0, 0),
(70, 4, 4, '20220528 105638', '3', 0, 0, 3, 0, 0),
(71, 36, 4, '20220528 105638', '1', 0, 0, 0, 0, 1),
(72, 18, 4, '20220528 105638', '5', 5, 0, 0, 0, 0),
(73, 16, 4, '20220528 105638', '4', 0, 4, 0, 0, 0),
(74, 23, 6, '20220528 105638', '3', 0, 0, 3, 0, 0),
(75, 21, 6, '20220528 105638', '4', 0, 4, 0, 0, 0),
(76, 5, 6, '20220528 105638', '2', 0, 0, 0, 2, 0),
(77, 24, 6, '20220528 105638', '2', 0, 0, 0, 2, 0),
(78, 22, 6, '20220528 105638', '1', 0, 0, 0, 0, 1),
(79, 20, 6, '20220528 105638', '5', 5, 0, 0, 0, 0),
(80, 28, 6, '20220528 105638', '3', 0, 0, 3, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `survey`
--

CREATE TABLE `survey` (
  `id_survey` varchar(20) NOT NULL,
  `id_admin` int(11) NOT NULL,
  `nama` varchar(35) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `email` varchar(35) NOT NULL,
  `telepon` varchar(12) NOT NULL,
  `dateSurvey` date NOT NULL,
  `isi_pesan` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `survey`
--

INSERT INTO `survey` (`id_survey`, `id_admin`, `nama`, `alamat`, `email`, `telepon`, `dateSurvey`, `isi_pesan`) VALUES
('20220528 103337', 2, 'RIZKINA', 'Indonesia', 'rizkina@gmail.com', '032334566789', '2022-05-28', 'perlu peningkatan kinerja,,'),
('20220528 105638', 3, 'AZKADINA', 'Indonesia', 'azkadina@gmail.com', '081241335647', '2022-05-28', 'kinerja belum maksimal');

-- --------------------------------------------------------

--
-- Table structure for table `user_admin`
--

CREATE TABLE `user_admin` (
  `id_admin` int(11) NOT NULL,
  `nama` varchar(35) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `email` varchar(35) NOT NULL,
  `telepon` varchar(12) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(50) NOT NULL,
  `foto` varchar(30) NOT NULL,
  `akses` enum('1','2') NOT NULL DEFAULT '2'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_admin`
--

INSERT INTO `user_admin` (`id_admin`, `nama`, `alamat`, `email`, `telepon`, `username`, `password`, `foto`, `akses`) VALUES
(1, 'AQILA-ADIVA', 'Indonesia', 'aqila.adiva@gmail.com', '082345161368', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'admin.png', '1'),
(2, 'RIZKINA', 'Indonesia', 'rizkina@gmail.com', '032334566789', 'rizkina', '54e7e7249525774d22f36ca352c0f045', '', '2'),
(3, 'AZKADINA', 'Indonesia', 'azkadina@gmail.com', '081241335647', 'azkadina', 'b88e257de855f9e771b6917d83123527', '', '2');

-- --------------------------------------------------------

--
-- Table structure for table `variabel`
--

CREATE TABLE `variabel` (
  `id_variabel` int(11) NOT NULL,
  `pertanyaan` varchar(555) NOT NULL,
  `id_dimensi` int(11) NOT NULL,
  `tgl_input` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `variabel`
--

INSERT INTO `variabel` (`id_variabel`, `pertanyaan`, `id_dimensi`, `tgl_input`) VALUES
(1, 'Kantor yang terlihat bersih dan nyaman ', 2, '2021-09-04 07:40:38'),
(2, 'Mendengarkan kebutuhan dan menerima saran/masukan dari masyarakat', 1, '2021-09-04 07:44:10'),
(3, 'Kesabaran dan ketelatenan pegawai dalam melayani masyarakat ', 3, '2021-09-05 09:07:36'),
(4, 'Setiap masyarakat mendapatkan pelayanan yang memuaskan', 4, '2021-09-05 09:08:18'),
(5, 'Layanan Call Center 24 Jam', 6, '2021-09-05 09:09:16'),
(6, ' Ruang tunggu masyarakat yang bersih dan nyaman', 2, '2021-09-17 10:35:44'),
(7, ' Ketersediaan fasilitas (Wi-Fi, toilet, no smoking area)', 1, '2021-09-17 11:27:46'),
(8, 'Pegawai ini megenakan seragam kerja sesuai dengan hari yang sudahh di tentukan', 2, '2021-09-19 23:44:26'),
(9, ' Pegawai menerima komplain dari masyarakat', 1, '2021-09-17 11:28:30'),
(10, ' Pegawai tidak membedakan status sosial dalam hal pelayanan', 1, '2021-09-17 11:28:48'),
(11, ' Tidak terjadi antrian panjang saat proses kepengurusan berkas', 2, '2021-09-17 11:30:38'),
(12, ' Ketersediaan tempat parkir yang memadai', 2, '2021-09-17 11:31:03'),
(13, ' Pegawai senantiasa sopan dan senyum dalam menyapa masyarakat', 3, '2021-09-17 11:37:20'),
(14, ' Kecepatan pegawai dalam menanggapi keluhan masyarakat', 3, '2021-09-17 11:38:00'),
(15, ' Pegawai bersedia membantu pelanggan jika dibutuhkan oleh masyarakat.', 3, '2021-09-17 11:40:06'),
(16, ' Pelayanan diberikan dalam waktu yang cepat', 4, '2021-09-17 11:42:38'),
(17, ' Keakuratan/ketepatan informasi yang diberikan oleh pegawai', 4, '2021-09-17 11:42:58'),
(18, ' Pelayanan yang profesional selama jam kerja', 4, '2021-09-17 11:44:41'),
(19, ' Pegawai bersedia membantu pelanggan jika dibutuhkan', 4, '2021-09-17 11:45:04'),
(20, ' Tidak ada kekeliruan pada saat proses administrasi ', 6, '2021-09-17 11:46:13'),
(21, ' Pegawai memberikan jaminan terpercaya pada masyarakat', 6, '2021-09-17 11:46:34'),
(22, ' Kemudahan memperoleh informasi pelayanan', 6, '2021-09-17 11:46:55'),
(23, ' Jaminan legalitas yang akurat', 6, '2021-09-17 11:47:26'),
(24, ' Kemampuan petugas dalam menyelesaikan pekerjaan', 6, '2021-09-17 11:47:44'),
(25, ' Ketersediaan papan informasi dan brosur', 2, '2021-09-19 22:20:03'),
(26, ' Kehandalan petugas memberikan pelayanan tidak berbelit belit', 3, '2021-09-19 22:24:41'),
(27, ' Letak kantor mudah di jangkau', 2, '2021-09-19 22:33:26'),
(28, ' Pegawai membuat masyarakat merasa aman', 6, '2021-09-19 22:37:37'),
(29, 'sungguh - sungguh mengutamakan kepentingan masyarakat ', 1, '2021-09-19 22:44:32'),
(30, ' Pegawai yang memahami kebutuhan masyarakat', 1, '2021-09-19 22:46:04'),
(31, ' Pegawai bersikap sopan saat berbicara di telepon', 1, '2021-09-19 23:03:23'),
(32, 'pegawai menggunakan bahasa yang di mengerti', 1, '2021-09-19 23:04:32'),
(33, ' prosedur menyampaikkan informasi jelass dan mudah di mengerti', 1, '2021-09-19 23:05:27'),
(34, ' pegawai bersikap ramah bila masyarakat mengajukan pertanyaan', 1, '2021-09-19 23:06:28'),
(35, 'pegawai dapat bekerja sama dengan masyarakat', 3, '2021-09-19 23:08:44'),
(36, ' pegawai selalu mematuhi peraturan tata tertip yang telah di tetapkan', 4, '2021-09-19 23:12:23'),
(37, ' Pegawai mengerjakan tugas dengan penuh teliti', 3, '2021-09-19 23:14:54'),
(38, ' Fasiliitas toilet yang di sediakan layak di pakai', 2, '2021-09-19 23:38:34'),
(39, ' Pegawai  tidak pernah melakukan pertengkaran dengan pegawai lain', 2, '2021-09-19 23:46:05'),
(40, ' Pegawai menunjukkan kesediaan melakukan pekerjaan tanpa di perintah oleh atasan', 2, '2021-09-19 23:49:11');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cover`
--
ALTER TABLE `cover`
  ADD PRIMARY KEY (`id_cover`);

--
-- Indexes for table `dimensi`
--
ALTER TABLE `dimensi`
  ADD PRIMARY KEY (`id_dimensi`);

--
-- Indexes for table `nilai_harapan`
--
ALTER TABLE `nilai_harapan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `nilai_variabel`
--
ALTER TABLE `nilai_variabel`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `survey`
--
ALTER TABLE `survey`
  ADD PRIMARY KEY (`id_survey`);

--
-- Indexes for table `user_admin`
--
ALTER TABLE `user_admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `variabel`
--
ALTER TABLE `variabel`
  ADD PRIMARY KEY (`id_variabel`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cover`
--
ALTER TABLE `cover`
  MODIFY `id_cover` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `dimensi`
--
ALTER TABLE `dimensi`
  MODIFY `id_dimensi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `nilai_harapan`
--
ALTER TABLE `nilai_harapan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;

--
-- AUTO_INCREMENT for table `nilai_variabel`
--
ALTER TABLE `nilai_variabel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;

--
-- AUTO_INCREMENT for table `user_admin`
--
ALTER TABLE `user_admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `variabel`
--
ALTER TABLE `variabel`
  MODIFY `id_variabel` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
