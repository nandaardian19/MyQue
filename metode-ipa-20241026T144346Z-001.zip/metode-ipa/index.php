<?php
header ('location:admin/sig_in.php');
?>