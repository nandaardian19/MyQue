<?php
$module = $_GET['module'];
if ($module == 'dimensi'){
	include "modul/mod_dimensi/dimensi.php";
}
elseif ($module == 'input_dimensi'){
	include "modul/mod_dimensi/input_dimensi.php";
}
elseif ($module == 'variabel'){
	include "modul/mod_variabel/variabel.php";
}
elseif ($module == 'input_variabel'){
	include "modul/mod_variabel/input_variabel.php";
}
elseif ($module == 'grafik'){
	include "grafik.php";
}
elseif ($module == 'survey'){
	include "survey.php";
}
elseif ($module == 'hasil'){
	include "modul/mod_report/hasil.php";
}
elseif ($module == 'user'){
	include "modul/mod_user/user.php";
}
elseif ($module == 'update_user'){
	include "modul/mod_user/update_user.php";
}
elseif ($module == 'input_admin'){
	include "modul/mod_admin/input_admin.php";
}
elseif ($module == 'admin'){
	include "modul/mod_admin/admin.php";
}
elseif ($module == 'member'){
	include "modul/mod_admin/member.php";
}
elseif ($module == 'profil'){
	include "modul/mod_profil/profil.php";
}
elseif ($module == 'input_profil'){
	include "modul/mod_profil/input_profil.php";
}
elseif ($module == 'berita'){
	include "modul/mod_berita/berita.php";
}
elseif ($module == 'input_berita'){
	include "modul/mod_berita/input_berita.php";
}
elseif ($module == 'galeri'){
	include "modul/mod_galeri/galeri.php";
}
elseif ($module == 'input_galeri'){
	include "modul/mod_galeri/input_galeri.php";
}
elseif ($module == 'pelayanan'){
	include "modul/mod_pelayanan/pelayanan.php";
}
elseif ($module == 'input_pelayanan'){
	include "modul/mod_pelayanan/input_pelayanan.php";
}
elseif ($module == 'kategori_berita'){
	include "modul/mod_kategori/kategori_berita.php";
}
elseif ($module == 'input_kategori_berita'){
	include "modul/mod_kategori/input_kategori_berita.php";
}
elseif ($module == 'cover'){
	include "modul/mod_cover/cover.php";
}
elseif ($module == 'input_cover'){
	include "modul/mod_cover/input_cover.php";
}
elseif ($module == 'pesan'){
	include "modul/mod_pesan/pesan.php";
}
else{
include "home.php";
}
?>

