<?php
session_start();
include "../include/koneksi.php";
	$username=$_POST['username'];
	$password=md5($_POST['password']);
$query=mysqli_query($GLOBALS["___mysqli_ston"], "select * from user_admin where username='$username' and password='$password'");
	$num=mysqli_num_rows($query);
	$r=mysqli_fetch_array($query);
	
	if($num >= 1){
		$_SESSION['id_admin']=$r['id_admin'];
		$_SESSION['akses']=$r['akses'];
		header("location:media.php");
	}else{
		echo "
		<script type='text/javascript'>
		alert('Username & Password Tidak Sesuai..!');
		history.back(self);
		</script>
		";
	}
?>
