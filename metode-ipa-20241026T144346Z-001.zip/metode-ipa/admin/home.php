<div class="row">
							<div class="col-xs-12">
								<div class="page-title-box">
                                    <h4 class="page-title">Dashboard</h4>
                                    
                                    <div class="clearfix"></div>
                                </div>
							</div>
						</div>
                        <!-- end row -->


<div class="row">
<div class="col-sm-8">

<div class="property-detail-wrapper">
<div class="row">
<div class="col-md-12">
 <!-- START carousel-->
<div id="carousel-example-captions" data-ride="carousel" class="carousel slide">
                                        <ol class="carousel-indicators">
                                            <li data-target="#carousel-example-captions" data-slide-to="0" class="active"></li>
                                            <li data-target="#carousel-example-captions" data-slide-to="1"></li>
                                            <li data-target="#carousel-example-captions" data-slide-to="2"></li>
                                        </ol>
                                        <div role="listbox" class="carousel-inner">
<?php
$a=mysqli_query($GLOBALS["___mysqli_ston"], "select*from cover where id_cover='1'");
	while($c=mysqli_fetch_array($a)){
?>
                                            <div class="item active">
                                                <img src="cover/<?php echo $c['foto']; ?>" alt="First slide image">
                                                <div class="carousel-caption">
                                                    <h3 class="text-white font-600"><?php echo $c['judul']; ?></h3>

                                                </div>
                                            </div>
<?php } ?>
<?php
$a=mysqli_query($GLOBALS["___mysqli_ston"], "select*from cover order by id_cover desc");
	while($c=mysqli_fetch_array($a)){
?>
                                            <div class="item">
                                                <img src="cover/<?php echo $c['foto']; ?>" alt="First slide image">
                                                <div class="carousel-caption">
                                                    <h3 class="text-white font-600"><?php echo $c['judul']; ?></h3>

                                                </div>
                                            </div>
<?php } ?>
                                            
                                        </div>
                                        <a href="#carousel-example-captions" role="button" data-slide="prev" class="left carousel-control"> <span aria-hidden="true" class="fa fa-angle-left"></span> <span class="sr-only">Previous</span> </a>
                                        <a href="#carousel-example-captions" role="button" data-slide="next" class="right carousel-control"> <span aria-hidden="true" class="fa fa-angle-right"></span> <span class="sr-only">Next</span> </a>
</div>
<!-- END carousel--></div></div></div></div>

                <div class="row">
                    <div class="col-md-2 col-sm-2">
                        <div class="card-box widget-box-two widget-two-success">
                            <i class="mdi mdi-account-convert widget-two-icon"></i>
                            <div class="wigdet-two-content">
                            <?php $r = mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM survey")); ?>
                                <p class="m-0 text-uppercase font-600 font-secondary text-overflow" title="Statistics">responden</p>
                                <h2><?php echo $r; ?> <small><i class="mdi mdi-arrow-up text-success"></i></small></h2>
                                <p class="text-muted m-0"><b>Total Responden</b></p>
                            </div>
                        </div>
                    </div><!-- end col -->

                    <div class="col-md-2 col-sm-2">
                        <div class="card-box widget-box-two widget-two-danger">
                            <i class="mdi mdi-cube-outline widget-two-icon"></i>
                            <div class="wigdet-two-content">
                            <?php $r1 = mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM dimensi")); ?>
                                <p class="m-0 text-uppercase font-600 font-secondary text-overflow" title="User Today">Dimensi</p>
                                <h2><?php echo $r1; ?>  <small><i class="mdi mdi-arrow-down text-danger"></i></small></h2>
                                <p class="text-muted m-0"><b>Total Dimensi</b></p>
                            </div>
                        </div>
                    </div><!-- end col -->

                    <div class="col-md-2 col-sm-2">
                        <div class="card-box widget-box-two widget-two-primary">
                            <i class="mdi mdi-comment-check widget-two-icon"></i>
                            <div class="wigdet-two-content">
                            <?php $r2 = mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM variabel")); ?>
                                <p class="m-0 text-uppercase font-600 font-secondary text-overflow" title="User This Month">Variabel</p>
                                <h2><?php echo $r2; ?> <small><i class="mdi mdi-arrow-up text-success"></i></small></h2>
                                <p class="text-muted m-0"><b>Total Variabel</b></p>
                            </div>
                        </div>
                    </div><!-- end col -->

                    <div class="col-md-2 col-sm-2">
                        <div class="card-box widget-box-two widget-two-warning">
                            <i class="mdi mdi-calendar-plus widget-two-icon"></i>
                            <div class="wigdet-two-content">
                            <?php $r3 = mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM survey WHERE MONTH(dateSurvey)=MONTH(NOW())")); ?>
                                <p class="m-0 text-uppercase font-600 font-secondary text-overflow" title="Request Per Minute">Responden Bulan</p>
                                <h2><?php echo $r3; ?> <small><i class="mdi mdi-arrow-down text-danger"></i></small></h2>
                                <p class="text-muted m-0"><b>Total Data</b></p>
                            </div>
                        </div>
                    </div><!-- end col -->

                </div>
                <!-- end row -->


                </div></div>
                <!-- end row -->
                
                