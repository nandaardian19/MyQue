<?php
define('lang_Select','Tallózás');
define('lang_Erase','Törlés');
define('lang_Open','Megnyitás');
define('lang_Confirm_del','Biztos vagy benne, hogy tötlöd ezt a fájlt?');
define('lang_All','Összes');
define('lang_Files','Fájlok');
define('lang_Images','Képek');
define('lang_Archives','Archívum');
define('lang_Error_Upload','The uploaded file exceeds the max size allowed.');
define('lang_Error_extension','File extension is not allowed.');
define('lang_Upload_file','Fájl feltöltése');
define('lang_Filter','Szűrő');
define('lang_Videos','Videó');
define('lang_Music','Zene');
define('lang_New_Folder','Új mappa');
define('lang_Folder_Created','Mappa létrehozva');
define('lang_Existing_Folder','Mappa már létezik');
define('lang_Confirm_Folder_del','Biztos, hogy törlöd a könyvtárat és annak tartalmát?');
define('lang_Return_Files_List','Vissza a fájllistához');
define('lang_Preview','Előnézet');
define('lang_Download','Letöltés');
define('lang_Insert_Folder_Name','Insert folder name:');
define('lang_Root','root');
?>
