<?php
define('lang_Select','Seleccionar');
define('lang_Erase','Eliminar');
define('lang_Open','Abrir');
define('lang_Confirm_del','Tem certeza que pretende eliminar este arquivo?');
define('lang_All','Todos');
define('lang_Files','Ficheiros');
define('lang_Images','Imagens');
define('lang_Archives','Compactados');
define('lang_Error_Upload','O ficheiro enviado é maior que o limite permitido.');
define('lang_Error_extension','Extensão não permitida.');
define('lang_Upload_file','Carregar ficheiro');
define('lang_Filter','Filtro');
define('lang_Videos','Vídeos');
define('lang_Music','Música');
define('lang_New_Folder','Nova pasta');
define('lang_Folder_Created','Pasta criada com sucesso');
define('lang_Existing_Folder','Pasta existente');
define('lang_Confirm_Folder_del','Tem certeza que pretende eliminar a pasta e todo o seu conteúdo?');
define('lang_Return_Files_List','Voltar à lista de ficheiros');
define('lang_Preview','Pré-visualizar');
define('lang_Download','Descarregar');
define('lang_Insert_Folder_Name','Insira o nome da pasta:');
define('lang_Root','root');
?>
