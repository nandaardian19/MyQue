<div class="sub-heard-part">
<ol class="breadcrumb m-b-0">
<li><a href="media.php">Home</a></li>
<li><a href="?module=dimensi">Tabel Data</a></li>
<li class="active">Form Input</li>
</ol>
</div>
<!--/sub-heard-part-->	
<!--/forms-->
<div class='card-box'>
<div class='row'>
<div class='col-sm-12 col-xs-12 col-md-12'>
<div id='p-20'>

<?php
if(isset($_POST['simpan'])){
$nama_dimensi 	= $_POST['nama_dimensi'];
$tgl_input = date('Y-m-d H:i:s');
$cek = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM dimensi WHERE nama_dimensi='$nama_dimensi'");
if(mysqli_num_rows($cek) == 0){	
$a=mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO dimensi(nama_dimensi,tgl_input) VALUES('$nama_dimensi','$tgl_input')");
if($a){
echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Data Berhasil Di Simpan.</div>';
echo "<meta http-equiv='refresh' content='2; url=?module=dimensi'>";
}else{
echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Data Gagal Di simpan !</div>';
				}
				}else{
echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Cek Kembali Isian.., Data Sudah Ada,..!</div>';
			}
			}
			
//Proses edit
$id_dimensi=$_GET['id_dimensi'];
$sql="select * from dimensi where id_dimensi='$id_dimensi'";
$query=mysqli_query($GLOBALS["___mysqli_ston"], $sql);
$r=mysqli_fetch_array($query);
if(isset($_POST['Edit'])){
$nama_dimensi 	= $_POST['nama_dimensi'];
$tgl_input = date('Y-m-d H:i:s');
$a=mysqli_query($GLOBALS["___mysqli_ston"], "UPDATE dimensi SET nama_dimensi='$nama_dimensi', tgl_input = '$tgl_input' WHERE id_dimensi='$id_dimensi'");
if($a){
echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Data Berhasil Di Simpan.</div>';
}else{
echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Data Gagal Di simpan !</div>';
}
echo "<meta http-equiv='refresh' content='2; url=?module=dimensi'>";
}
?>

<form action="" method="post" enctype="multipart/form-data" class="form-horizontal">
 
<div class="form-group row">
<label class="col-sm-2 control-label">Nama Dimensi</label>
<div class="col-sm-4">
<input name="nama_dimensi" value="<?php echo $r['nama_dimensi']; ?>" class="form-control" required="" data-errormessage-value-missing="isian masih kosong" />
</div>
</div>
<div class="form-group row">
<div class="col-sm-2">
<?php if(!$_GET['id_dimensi']){
		//bila mau tambah data yang tampil tombol simpan
		echo "<input name=\"simpan\" class=\"btn btn-success\" type=\"submit\" id=\"simpan\" value=\"Simpan\" />&nbsp;";
		echo "<input name=\"batal\" class=\"btn btn-danger\" type=\"button\" id=\"batal\" value=\"Batal\" onclick=\"window.location.href='?module=dimensi'\" />";
        } else {
		//Apabila mau edit yg tampil tombol edit dan hapus
		echo "<input name=\"Edit\" class=\"btn btn-success\" type=\"submit\" id=\"edit\" value=\"Simpan\" />&nbsp;";
		echo "<input name=\"batal\" class=\"btn btn-danger\" type=\"button\" id=\"batal\" value=\"Batal\" onclick=\"window.location.href='?module=dimensi'\" />";
} ?>
</div>
</div>

</form>
 	<!---->
</div>
</div>
</div></div>
<!--//grid-->
