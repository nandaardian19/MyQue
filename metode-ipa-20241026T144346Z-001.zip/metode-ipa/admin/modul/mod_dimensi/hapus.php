<?php
include "../../../include/koneksi.php";
$id_dimensi=$_GET['id_dimensi'];
$modal = mysqli_query($GLOBALS["___mysqli_ston"], "DELETE FROM dimensi WHERE id_dimensi='$id_dimensi'");
if($modal){
echo '<script>window.alert("Data Berhasil di Hapus");
       window.location=("../../media.php?module=dimensi")</script>';  
	}
?>