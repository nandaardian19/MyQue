<!--sub-heard-part-->
<div class="sub-heard-part">
<ol class="breadcrumb m-b-0">
<li><a href="media.php">Home</a></li>
<li class="active">Table</li>
</ol>
</div>
<!--//sub-heard-part-->
<div class="row">
<div class="col-lg-12">
<div class="panel panel-primary">
<div class="panel-heading"> Data Dimensi</div>
<div class="panel-body">
<div class="table-responsive">
<a href="?module=input_dimensi"><button class="btn btn-sm btn-success"><i class="fa fa-plus"></i> Tambah Data</button></a>
<!-- tables -->
<table class="table m-0 table-colored table-info table-striped table-bordered table-hover" id="datatable">
<thead>
<tr>
<th width="30"><b>No.</b></th>
<th><b>Nama Dimensi</b></th>
<th width="140"><b>Aksi</b></th>
</tr>
</thead>
<tr>                           
<?php
$view=mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM dimensi ORDER BY id_dimensi ASC");
$no=1;
while($data=mysqli_fetch_array($view)){
echo "

<td><center>$no</center></td>
<td>$data[nama_dimensi]</td>";
?>
<td><a href="?module=input_dimensi&id_dimensi=<?php echo  $data['id_dimensi']; ?>"><button class="btn-sm btn btn-success" id="tooltip-hover" title="Edit Data"><i class="mdi mdi-table-edit"></i></button></a>
<a href="#" onclick="confirm_modal('modul/mod_dimensi/hapus.php?&id_dimensi=<?php echo  $data['id_dimensi']; ?>');"><button class="btn-sm btn btn-danger" id="tooltip-animation" title="Hapus Data"><i class="mdi mdi-backspace"></i></button></a>
</td></tr>
<?php $no++;}?>
</table>

</div></div>
</div></div></div>

	<!--END PAGE CONTENT -->

 <!-- Modal Popup untuk delete--> 
<div class="modal fade" id="modal_delete">
  <div class="modal-dialog">
    <div class="modal-content" style="margin-top:100px;">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" style="text-align:center;">Anda yakin akan menghapus data ini.. ?</h4>
      </div>
                
      <div class="modal-footer" style="margin:0px; border-top:0px; text-align:center;">
        <a href="#" class="btn btn-danger btn-sm" id="delete_link">Hapus</a>
        <button type="button" class="btn btn-success btn-sm" data-dismiss="modal">Cancel</button>
      </div>
    </div>
  </div>
</div>

<!-- Javascript untuk popup modal Delete--> 
<script type="text/javascript">
    function confirm_modal(delete_url)
    {
      $('#modal_delete').modal('show', {backdrop: 'static'});
      document.getElementById('delete_link').setAttribute('href' , delete_url);
    }
</script>      

