
<?php
  include "../../../include/koneksi.php";
	$id_admin=$_GET['id_admin'];
	$modal=mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM user_admin WHERE id_admin='$id_admin'");
	while($r=mysqli_fetch_array($modal)){

			?>

<div class="modal-dialog">
    <div class="modal-content">

    	<div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            <h4 class="modal-title" id="myModalLabel">Edit Data Admin</h4>
        </div>

       <div class="modal-body">
        	<form action="modul/mod_user/proses_edit.php" name="modal_popup" enctype="multipart/form-data" method="POST">
        		
                <div class="form-group" style="padding-bottom: 5px;">
                  <label for="nama admin"><font color="#660033">Nama Lengkap</font></label>
                  <input type="hidden" name="id_admin"  class="form-control1" value="<?php echo $r['id_admin']; ?>" />
<input type="text" name="nama"  class="form-control1" value="<?php echo $r['nama']; ?>" placeholder="Nama Lengkap" required/>
                </div>
                <div class="form-group" style="padding-bottom: 5px;">
                  <label for="Nama User"><font color="#660033">Nama User</font></label>
                  <input type="text" name="username"  class="form-control1" value="<?php echo $r['username']; ?>" placeholder="Nama User" required/>
                </div>
                <div class="form-group" style="padding-bottom: 5px;">
                  <label for="password"><font color="#660033">Password</font></label>
                <input type="text" name="password"  class="form-control1" placeholder="Password" />
<?php
if($_GET['id_admin']){
echo "<br><font color='red'>Apabila password tidak diubah, silahkan dikosongkan saja</font>";
}
?>
                </div>
                <div class="form-group" style="padding-bottom: 5px;">
<label for="foto"><font color="#660033">Foto</font></label>
 <?php if($_GET['id_admin']){
				//tampilkan foto saat mau ngedit
				 echo "<img src='foto_admin/$r[foto]' width=110 height=110> <br />";
				} 
				?>
				  <input name="foto" type="file" id="foto" />
                </div>
              <div class="modal-footer">
                  <button class="btn btn-sm btn-primary" type="submit">
                      Update
                  </button>
                  <button type="reset" class="btn btn-sm btn-danger"  data-dismiss="modal" aria-hidden="true">
                    Batal
                  </button>
              </div>
              </form>
             <?php } ?>
            </div>
        </div>
    </div>
