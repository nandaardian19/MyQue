
<?php
include "../../../include/koneksi.php";
   $id_admin=$_POST['id_admin'];
	$nama=$_POST['nama'];
	$username=$_POST['username'];
	$password=md5($_POST['password']);
$foto=$_FILES['foto']['name'];
 if(strlen($foto)>0){ 
 
 	if(is_uploaded_file($_FILES['foto']['tmp_name'])){
	move_uploaded_file($_FILES['foto']['tmp_name'],"../../foto_admin/".$foto);
	}
$modal=mysqli_query($GLOBALS["___mysqli_ston"], "update user_admin set foto='$foto' where id_admin='$id_admin'");
}
  if (!empty($_POST[password])){
    $password = md5($_POST[password]);
	$modal=mysqli_query($GLOBALS["___mysqli_ston"], "UPDATE user_admin SET nama='$nama',username='$username',password='$password' WHERE id_admin='$id_admin'");
	if($modal){
echo "<script>alert('Data Berhasil di Update!'); window.location = '../../media.php'</script>";
}
	  }else{
		  
$modal=mysqli_query($GLOBALS["___mysqli_ston"], "UPDATE user_admin SET nama='$nama',username='$username' WHERE id_admin='$id_admin'");
if($modal){
echo "<script>alert('Data Berhasil di Update!'); window.location = '../../media.php'</script>";
}
	  }
?>
