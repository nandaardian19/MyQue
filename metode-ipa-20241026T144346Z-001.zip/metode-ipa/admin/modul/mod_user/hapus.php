<?php
  include "../../../include/koneksi.php";
$id_admin=$_GET['id_admin'];
$modal=mysqli_query($GLOBALS["___mysqli_ston"], "Delete FROM user_admin WHERE id_admin='$id_admin'");
header('location:../../media.php');
?>