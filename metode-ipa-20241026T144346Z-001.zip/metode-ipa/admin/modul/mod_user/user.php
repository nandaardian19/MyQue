 <!-- Page-Title -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-title-box">
                            <h4 class="page-title">Profile</h4>
                        </div>
                    </div>
                </div>
                <!-- end page title end breadcrumb -->


                <div class="row">
                    <div class="col-sm-12">
                        <div class="card-box">
                            <div class="row">
                                <div class="col-lg-3 col-md-4">
                                    <div class="text-center card-box">
                                        <div class="member-card">
                                       <?php
$view=mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM user_admin WHERE id_admin='$_GET[id]'");
			  $no=1;
			  while($data=mysqli_fetch_array($view)){
			  ?> 
                                            <div class="thumb-xl member-thumb m-b-10 center-block">
 <?php
$foto=$data['foto'];
if(empty($foto)){
?>
<img src="foto_admin/user.PNG" class="img-circle img-thumbnail" alt="profile-image">
<?php
					}
					else{
					?>
<img src="foto_admin/<?php echo $data['foto']; ?>" class="img-circle img-thumbnail" alt="profile-image">
<?php
}
?>
                                                <i class="mdi mdi-star-circle member-star text-success" title="verified user"></i>
                                            </div>

                                            <div class="">
                                                <h4 class="m-b-5"><?php echo $data['username']; ?></h4>
                                                <p class="text-muted"><?php echo $data['email']; ?></p>
                                            </div>

                                            <hr/>

                                            <div class="text-left">
                                <p class="text-muted font-13"><strong>Full Name :</strong> <span class="m-l-15"><?php echo $data['nama']; ?></span></p>
                                <p class="text-muted font-13"><strong>Phone :</strong><span class="m-l-15"><?php echo $data['telepon']; ?></span></p>

                                                <p class="text-muted font-13"><strong>Email :</strong> <span class="m-l-15"><?php echo $data['email']; ?></span></p>

                                                <p class="text-muted font-13"><strong>Location :</strong> <span class="m-l-15"><?php echo $data['alamat']; ?></span></p>
                                            </div>

<?php } ?> 
                                        </div>

                                    </div> <!-- end card-box -->

                                </div> <!-- end col -->

                                <div class="col-md-8 col-lg-8">
                                    <h4>Setting</h4>

                                    <div class="row m-t-20">
<div class="card-box">
<div class="table-responsive">
<table class="table table table-hover m-0">
<thead>
                                        <tr>
	  
                                        <th>No.</th>
                                        <th>Nama Lengkap </th>
                                        <th>Username</th>
                                        <th><div align="center">Foto</div> </th>
	                                    <th width="30">Action</th> 
	  
                                       </tr>
                                      </thead>
                                      
                                       <?php
$view=mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM user_admin WHERE id_admin='$_GET[id]'");
			  $no=1;
			  while($data=mysqli_fetch_array($view)){
			  ?>          
			
			<tr>
				 <td><div align="center"><?php echo $no; ?></div></td>
                <td><?php echo $data['nama']; ?></td>
                <td><?php echo $data['username']; ?></td>
<td><center>
 <?php
$foto=$data['foto'];
if(empty($foto)){
?>
<img src="foto_admin/user.PNG" class="thumb-sm img-circle" />
<?php
					}
					else{
					?>
<img src="foto_admin/<?php echo $data['foto']; ?>" class="thumb-sm img-circle" />
<?php
}
?>
</center>
</td>
              <td>
         <a href="?module=update_user&id_admin=<?php echo  $data['id_admin']; ?>"><button class="btn btn-outline btn-success btn-sm" title="Edit"><i class="mdi mdi-pencil-box "></i></button></a>
         </td>		    
              </tr>
             <?php $no++;}?>
                                </table>
                                    </div> <!-- end row -->

</div></div></div></div></div>
</div></div>