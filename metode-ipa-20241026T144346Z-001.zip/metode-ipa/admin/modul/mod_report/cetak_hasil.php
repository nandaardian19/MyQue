<?php
session_start();
if (empty($_SESSION['id_admin']))
    error_reporting(E_ALL^(E_NOTICE));
include "../../../include/koneksi.php";
include "../../../include/fungsi_indotgl.php";
include "../../../include/fungsi_print.php";
if ($_SESSION['id_admin'] == "") {
    echo "<script>parent.location ='media.php';</script>";
    exit;
}
if (isset($_SESSION['id_admin'])) {
    date_default_timezone_set("Asia/Makassar");
    ?>
<script type="text/javascript">
	window.print() 
	</script>

	<style type="text/css">
	#print {
		margin:auto;
		border:0px solid #2A9FAA;
		text-align:center;
		font-family:"Century Gothic", Courier, monospace;
		width:1000px;
		font-size:13px;
	}
	#print .title {
		margin:20px;
		text-align:right;
		font-family:"Courier New", Courier, monospace;
		font-size:13px;
	}
	#print span {
		text-align:center;
		font-family:"Trebuchet MS", Arial, Helvetica, sans-serif;	
		font-size:18px;
	}
	#print table {
		border-collapse:collapse;
		width:100%;
		margin:10px;
	}
	#print .table1 {
		border-collapse:collapse;
		width:80%;
		text-align:center;
	}
	#print .table2 {
		margin:20px;
		border-collapse:collapse;;
		width:100%;
	}
	#print table hr {
		border:3px dashed #A0A0A4;

	}
	#print .ttd1 {
		margin-right:200px;
	}
	#print .ttd2 {
		float:right;
		width:400px;
	}
	#print table th {
		color:#000;
		font-family:"Century Gothic", Courier, monospace;
		font-size:14px;
	}
	#print table td {
		color:#000;
		font-family:"Century Gothic", Courier, monospace;
		font-size:13px;
	}

	#print .grand {
		width:700px;
		padding:10px;
		text-align:left;	
	}
	#print .grand table {
		margin-left:-90px;	
	}
	#logo{
		width:111px;
		height:90px;
		padding-top:10px;	
		margin-left:10px;
	}

	h2,h3{
		margin: 0px 0px 0px 0px;
	}
	#keterangan {
		margin:auto;
		border:0px solid #2A9FAA;
		text-align:left;
		font-family:"Century Gothic", Courier, monospace;
		width:1000px;
		font-size:13px;
	}

	</style>

	<title>hasil-analisis</title>
    <link rel="shortcut icon" href="../../assets/images/lg.png">
	<?php
	$tanggal = tgl_indo(date("Y-m-d"));
	$jam     = date("H:i:s");
	$hari_ini = $seminggu[$hari];
	?>
<div id="print">
	
<table class='table1'>
<tr>
<td align="left"><img src='../../assets/images/lg.png' height="80" width="80"></td>
<td>
<h3> KOP PERUSAHAAN/INSTANSI</h3>
					<p style="font-size:12px;"><i> Alamat : 
						<?php echo $Alamat;?></i>
					</p>
</td>
</tr>
</table>	
<strong><hr></strong>
<h3>Hasil Survey Kepuasan Pelanggan Sobat Wedding  </h3>
<?php
$dataGet = explode('#', $_GET['tanggal']);
$tglawal = $dataGet[0];
$tglakhir = $dataGet[1];

$no = 1;
				
?>

<h3> Periode <?php  echo date("M Y",strtotime($tglawal))." - ".date("M Y",strtotime($tglakhir)); ?></h3>




<table class="table" border="1">
<tr>
<th>No.</th>
<th colspan='2'><center> Variabel </center></th>
<th bgcolor="#FFFF99"><center><b>Harapan (Yi)</b></center></th>
<th bgcolor="#99FFCC"><center><b>Kinerja (Xi)</b></center></th>
<th bgcolor="#33FFFF"><center> Nilai TKi </center></th>
<th width="90" bgcolor="#FFCCFF"><center> Keterangan </center></th>
</tr>

<?php
$ql = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM survey WHERE DATE(dateSurvey) > '$tglawal' AND DATE(dateSurvey) <= '$tglakhir'");
			$no = 1;
			$sql = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM dimensi");
			while($data = mysqli_fetch_array($sql)){
				$id = $data['id_dimensi'];
				echo "<tr valign='top'>
						<th>($no)</th>
						<th colspan='2' class='table-colored-full table-full-primary'>$data[nama_dimensi]</th>
						<td class='table-colored-full table-full-primary' colspan='10'></td>
					</tr>";
					
$hasil = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM variabel, dimensi WHERE variabel.id_dimensi = '$id' AND variabel.id_dimensi = dimensi.id_dimensi ORDER BY dimensi.id_dimensi");
$n_dimensi = mysqli_num_rows($hasil);
$tot_responden = mysqli_num_rows($ql);
				$i = 1;
				while ($r = mysqli_fetch_array($hasil)){
				
					echo "<tr>
							<td> </td>
							<td>$i </td>
							<td>$r[pertanyaan]</td>";
$kr = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT AVG(nilai_variabel.nilai_kinerja) As total FROM nilai_variabel JOIN survey ON survey.id_survey = nilai_variabel.id_survey WHERE id_variabel = '$r[id_variabel]' AND DATE(survey.dateSurvey) > '$tglawal' AND DATE(survey.dateSurvey) <= '$tglakhir'");
while($kj = mysqli_fetch_array($kr)){
$tot_kinerja = $kj['total'];
echo "<td><center>".number_format($tot_kinerja,2,',','.')." </center></td>";
}
$hr = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT AVG(nilai_harapan.nilai_harapan) As harapan FROM nilai_harapan JOIN survey ON survey.id_survey = nilai_harapan.id_survey WHERE id_variabel = '$r[id_variabel]' AND DATE(survey.dateSurvey) > '$tglawal' AND DATE(survey.dateSurvey) <= '$tglakhir'");
while($h = mysqli_fetch_array($hr)){

$tot_harapan = $h['harapan'];
$tot_ipa = ($tot_harapan != 0) ? ($tot_kinerja / $tot_harapan) * 100 : 0;
$ket =$tot_ipa;
if ($tot_ipa>200.00) 
$ket="<font color='#008800'>Sangat Puas</font>"; 
else if ($tot_ipa<=200.00 AND $tot_ipa>100.00)
$ket="<font color='#008800'>Sangat Puas</font>"; 
else if ($tot_ipa<=100.01 AND $tot_ipa>70.00)
$ket="<font color='#FF9900'>Puas</font>"; 
else if ($tot_ipa<=0 AND $tot_ipa>70.01) 
$ket="<font color='#BB0000'>Tidak Puas</font>"; 
else
$ket="<font color='#BB0000'>Tidak Puas</font>";

echo "<td><center>".number_format($tot_harapan,2,',','.')." </center></td>";
}

echo "<td><center>".number_format($tot_ipa,2,',','.')." </center></td>
<td>$ket </td></tr>";
					$i++;
				}
				echo "<br>";
				$no++;
			}
			?>
		</table> 
</div>

<!-- Tabel hasil analisis -->
<table class="table" border="1">
    <!-- Konten tabel (seperti yang Anda miliki) -->
</table>

<?php
// Calculate kinerja rata-rata
$total_kinerja = 0;
$total_variabel_kinerja = 0;
foreach ($hasil as $r) {
    $kr = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT AVG(nilai_variabel.nilai_kinerja) As total FROM nilai_variabel JOIN survey ON survey.id_survey = nilai_variabel.id_survey WHERE id_variabel = '$r[id_variabel]' AND DATE(survey.dateSurvey) > '$tglawal' AND DATE(survey.dateSurvey) <= '$tglakhir'");
    while ($kj = mysqli_fetch_array($kr)) {
        $total_kinerja += $kj['total'];
        $total_variabel_kinerja++;
    }
}
$kinerja_rata_rata = ($total_variabel_kinerja != 0) ? $total_kinerja / $total_variabel_kinerja : 0;

// Calculate harapan rata-rata
$total_harapan = 0;
$total_variabel_harapan = 0;
foreach ($hasil as $r) {
    $hr = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT AVG(nilai_harapan.nilai_harapan) As harapan FROM nilai_harapan JOIN survey ON survey.id_survey = nilai_harapan.id_survey WHERE id_variabel = '$r[id_variabel]' AND DATE(survey.dateSurvey) > '$tglawal' AND DATE(survey.dateSurvey) <= '$tglakhir'");
    while ($h = mysqli_fetch_array($hr)) {
        $total_harapan += $h['harapan'];
        $total_variabel_harapan++;
    }
}
$harapan_rata_rata = ($total_variabel_harapan != 0) ? $total_harapan / $total_variabel_harapan : 0;

// Calculate nilai rata-rata TKi
$nilai_rata_rata_tki = ($harapan_rata_rata != 0) ? ($kinerja_rata_rata / $harapan_rata_rata) * 100 : 0;

// Tentukan keterangan berdasarkan nilai $nilai_rata_rata_tki
if ($nilai_rata_rata_tki >= 200.00) {
    $status_kepuasan = "Sangat Puas";
    $ket = "<font color='#008800'>$status_kepuasan</font>";
} elseif ($nilai_rata_rata_tki >= 100.00 && $nilai_rata_rata_tki <= 200.00) {
    $status_kepuasan = "Puas";
    $ket = "<font color='#008800'>$status_kepuasan</font>";
} elseif ($nilai_rata_rata_tki > 70.00 && $nilai_rata_rata_tki <= 100.00) {
    $status_kepuasan = "Puas";
    $ket = "<font color='#FF9900'>$status_kepuasan</font>";
} elseif ($nilai_rata_rata_tki > 0 && $nilai_rata_rata_tki <= 70.00) {
    $status_kepuasan = "Tidak Puas";
    $ket = "<font color='#BB0000'>$status_kepuasan</font>";
} else {
    $status_kepuasan = "Tidak Puas";
    $ket = "<font color='#BB0000'>$status_kepuasan</font>";
}
?>

<!-- Kesimpulan -->
<div id="keterangan">	
<div style="margin-left: 20px;">
    <h3>Kesimpulan:</h3>
    <p>
        Berdasarkan hasil analisis Metode Importance Performance Analysis (IPA) di atas, dapat disimpulkan bahwa:
    </p>
    <ul style="padding-left: 20px;">
        <li>Jumlah responden: <?php echo $tot_responden; ?></li>
		<li>Kinerja rata-rata: <?php echo number_format($kinerja_rata_rata, 2, ',', '.'); ?></li>
        <li>Harapan rata-rata: <?php echo number_format($harapan_rata_rata, 2, ',', '.'); ?></li>
        <li>Nilai rata-rata TKi: <?php echo number_format($nilai_rata_rata_tki, 2, ',', '.'); ?></li>
		<li>Status Kepuasan Responden: <?php echo $ket; ?></li>
    </ul>
	<p>
	Berdasarkan hasil yang didapat, dapat disimpulkan bahwa responden merasa <?php echo strtolower($status_kepuasan); ?> terhadap kinerja yang telah dicapai.
    </p>
</div>
</div>



<br>
<div id="print">	
<table class="ttd2" align="right">
<tr>
<td width="100px" style="padding:20px 20px 20px 20px;" align="center">
<font face="Tahoma, Geneva, sans-serif" size="2"> Nama Tempat, <?php echo "$tanggal";?> <br>Pimpinan, </font>
                                 <br><br><br><br><br><br>
<strong><u><?php echo $dir;?></u><br></strong><small></small>


</td>
</tr>
</table>
</div>
<?php
}else{
	exit;
}
?>