<!--sub-heard-part-->
<div class="sub-heard-part">
    <ol class="breadcrumb m-b-0">
        <li><a href="media.php">Home</a></li>
        <li><a href="modul/mod_report/cetak_hasil.php" target="_blank">Print</a></li>
        <li class="active">Tables</li>
    </ol>
</div>
<!--//sub-heard-part-->

<div class="row">
    <div class="col-sm-12">
        <div class="form-group">
       
           
           
                
                <?php
                
                ?>
            </select>
        </div>
    </div>
</div>


<div class="row">
    <div class="col-sm-12">
        <div class="card-box table-responsive">
            <table class="table table-striped table-bordered table-hover table-colored-bordered table-bordered-danger">
            
                <tr>
                
                    <th class="table-colored-full table-full-inverse">No.</th>
                    <th class="table-colored-full table-full-inverse" colspan='2'><center>Variabel</center></th>
                    <td class="table-colored-full table-full-inverse"><center><b>HARAPAN (Yi)</b></center></td>
                    <td class="table-colored-full table-full-inverse"><center><b>KINERJA (Xi)</b></center></td>
                    <td class="table-colored-full table-full-inverse"><center><b>NILAI Tki</b></center></td>
                    <th class="table-colored-full table-full-inverse"><center>Keterangan</center></th>
                </tr>
                <h3>Hasil Survey Kepuasan Pelanggan Sobat Wedding</h3>
                
                
                
                <?php
$sql = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT dateSurvey FROM survey ORDER BY dateSurvey LIMIT 1 ");

$no = 1;
// $sql = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM dimensi");
while($data = mysqli_fetch_array($sql)){
	$tglawal = date("M Y",strtotime ($data['dateSurvey']));
}
				
?>
<?php
$sql = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT dateSurvey FROM survey ORDER BY dateSurvey DESC LIMIT 1 ");

$no = 1;
// $sql = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM dimensi");
while($data = mysqli_fetch_array($sql)){
	$tglakhir = date("M Y",strtotime ($data['dateSurvey']));
}
				
?>

<h3> Periode <?php  echo $tglawal    ." - ".    $tglakhir ;   ?> </h3>        
                <?php
                $ql = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM survey");
                $no = 1;
                $sql = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM dimensi");
                while($data = mysqli_fetch_array($sql)){
                    $id = $data['id_dimensi'];
                    echo "<tr class='table-dimension-row' data-dimension='$data[nama_dimensi]' valign='top'>
                            <th>($no)</th>
                            <th colspan='2' class='table-colored-full table-full-primary'>$data[nama_dimensi]</th>
                            <td class='table-colored-full table-full-primary' colspan='10'></td>
                          </tr>";

                    $hasil = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM variabel, dimensi WHERE variabel.id_dimensi = '$id' AND variabel.id_dimensi = dimensi.id_dimensi ORDER BY dimensi.id_dimensi");
                    $n_dimensi = mysqli_num_rows($hasil);
                    $tot_responden = mysqli_num_rows($ql);
                    $i = 1;
                    while ($r = mysqli_fetch_array($hasil)){
                        echo "<tr class='table-dimension-row' data-dimension='$data[nama_dimensi]'>
                                <td> </td>
                                <td>$i </td>
                                <td>$r[pertanyaan]</td>";
                        $kr = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT SUM(nilai_kinerja) As total FROM nilai_variabel WHERE id_variabel = '$r[id_variabel]'");
                        while($kj = mysqli_fetch_array($kr)){
                            $tot_kinerja = $kj['total'] / $tot_responden;
                            echo "<td>".number_format($tot_kinerja,2,',','.')." </td>";
                        }
                        $hr = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT SUM(nilai_harapan) As harapan FROM nilai_harapan WHERE id_variabel = '$r[id_variabel]'");
                        while($h = mysqli_fetch_array($hr)){
                            $tot_harapan = ($h['harapan'] != 0) ? $h['harapan'] / $tot_responden : 0;
                            $tot_ipa = ($tot_harapan != 0) ? ($tot_kinerja / $tot_harapan) * 100 : 0;
                            $ket = $tot_ipa;
                            if ($tot_ipa > 100.00) 
                                $ket="<font color='#008800'>Sangat Puas</font>"; 
                            else if ($tot_ipa <= 100.00 AND $tot_ipa > 91.01)
                                $ket="<font color='#008800'>Sangat Puas</font>"; 
                            else if ($tot_ipa <= 91.00 AND $tot_ipa > 70.00)
                                $ket="<font color='#FF9900'>Puas</font>"; 
                            else if ($tot_ipa <= 0 AND $tot_ipa > 70.01) 
                                $ket="<font color='#BB0000'>Tidak Puas</font>"; 
                            else
                                $ket="<font color='#BB0000'>Tidak Puas</font>";

                            echo "<td>".number_format($tot_harapan,2,',','.')." </td>";
                        }

                        echo "<td>".number_format($tot_ipa,2,',','.')." </td>
                        <td>$ket </td></tr>";
                        $i++;
                    }
                    echo "<br>";
                    $no++;
                }
                ?>
            </table> 
            <?php
// Calculate kinerja rata-rata
$total_kinerja = 0;
$total_variabel_kinerja = 0;
foreach ($hasil as $r) {
    $kr = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT AVG(nilai_kinerja) As total FROM nilai_variabel WHERE id_variabel = '$r[id_variabel]'");
    while ($kj = mysqli_fetch_array($kr)) {
        $total_kinerja += $kj['total'];
        $total_variabel_kinerja++;
    }
}
$kinerja_rata_rata = ($total_variabel_kinerja != 0) ? $total_kinerja / $total_variabel_kinerja : 0;

// Calculate harapan rata-rata
$total_harapan = 0;
$total_variabel_harapan = 0;
foreach ($hasil as $r) {
    $hr = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT AVG(nilai_harapan) As harapan FROM nilai_harapan WHERE id_variabel = '$r[id_variabel]'");
    while ($h = mysqli_fetch_array($hr)) {
        $total_harapan += $h['harapan'];
        $total_variabel_harapan++;
    }
}
$harapan_rata_rata = ($total_variabel_harapan != 0) ? $total_harapan / $total_variabel_harapan : 0;

// Calculate nilai rata-rata TKi
$nilai_rata_rata_tki = ($harapan_rata_rata != 0) ? ($kinerja_rata_rata / $harapan_rata_rata) * 100 : 0;

// Tentukan keterangan berdasarkan nilai $nilai_rata_rata_tki
if ($nilai_rata_rata_tki >= 200.00) {
    $status_kepuasan = "Sangat Puas";
    $ket = "<font color='#008800'>$status_kepuasan</font>";
} elseif ($nilai_rata_rata_tki >= 100.00 && $nilai_rata_rata_tki <= 200.00) {
    $status_kepuasan = "Puas";
    $ket = "<font color='#008800'>$status_kepuasan</font>";
} elseif ($nilai_rata_rata_tki > 70.00 && $nilai_rata_rata_tki <= 100.00) {
    $status_kepuasan = "Puas";
    $ket = "<font color='#FF9900'>$status_kepuasan</font>";
} elseif ($nilai_rata_rata_tki > 0 && $nilai_rata_rata_tki <= 70.00) {
    $status_kepuasan = "Tidak Puas";
    $ket = "<font color='#BB0000'>$status_kepuasan</font>";
} else {
    $status_kepuasan = "Tidak Puas";
    $ket = "<font color='#BB0000'>$status_kepuasan</font>";
}
?>
<div id="keterangan">	
<div style="margin-left: 20px;">
    <h3>Kesimpulan:</h3>
    <p>
        Berdasarkan hasil analisis Metode Importance Performance Analysis (IPA) di atas, dapat disimpulkan bahwa:
    </p>
    <ul style="padding-left: 20px;">
        <li>Jumlah responden: <?php echo $tot_responden; ?></li>
		<li>Kinerja rata-rata: <?php echo number_format($kinerja_rata_rata, 2, ',', '.'); ?></li>
        <li>Harapan rata-rata: <?php echo number_format($harapan_rata_rata, 2, ',', '.'); ?></li>
        <li>Nilai rata-rata TKi: <?php echo number_format($nilai_rata_rata_tki, 2, ',', '.'); ?></li>
		<li>Status Kepuasan Responden: <?php echo $ket; ?></li>
    </ul>
	<p>
	Berdasarkan hasil yang didapat, dapat disimpulkan bahwa responden merasa <?php echo strtolower($status_kepuasan); ?> terhadap kinerja yang telah dicapai.
    </p>
    <p>
	Pilih periode yang ingin Anda cetak: 
    </p>
        <form method="GET" action="modul/mod_report/cetak_hasil.php" target="_blank">
            <select name="tanggal">
                <option value="2023-01-01#2023-06-30">1 Januari 2023 - 30 Juni 2023</option>
                <option value="2023-07-01#2023-12-31">1 Juli 2023 - 31 Desember 2023</option>
            </select><br><br>
            <button class="btn btn-outline btn-primary btn-sm" type="submit">
                <i class="fa fa-print"></i> Cetak
            </button>
        </form>
</div>
</div>
        </div>
    </div>
</div>
