<!--sub-heard-part-->
<div class="sub-heard-part">
<ol class="breadcrumb m-b-0">
<li><a href="media.php">Home</a></li>
<li class="active">Table</li>
<li><a href="?module=input_cover">Entry Data Baru</a></li>
</ol>
</div>
<!--//sub-heard-part-->
<div class="row">
<div class="col-lg-12">
<div class="panel panel-info">
<div class="panel-heading"> Tabel Cover</div>
<div class="panel-body">
<div class="table-responsive">
<!-- tables -->
<table class="table table-striped table-bordered table-hover" id="datatable">
<thead>
<tr>
<th><b>No.</b></th>
<th><b>Judul </b></th>
<th><b>Gambar</b></th>
<th width="80"><b>Aksi</b></th>
</tr>
</thead>
 <?php
$view=mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM cover order by id_cover DESC");
			  $no=1;
			  while($data=mysqli_fetch_array($view)){
			            
			
			echo "
			<tr>
 <td><div align='center'>$no</div></td>
               <td>$data[judul]</td>";
                ?>
                <td><center><img src="cover/<?php echo $data['foto']; ?>" class="img-thumbnail" height="80" width="75" style="border: 3px solid #DDD;" /></center></td>
<td><a href="?module=input_cover&id_cover=<?php echo  $data['id_cover']; ?>"><button class="btn btn-outline btn-success btn-xs" title="Edit"><i class="fa fa-edit"></i></button></a>
<a href="#" onclick="confirm_modal('modul/mod_cover/hapus.php?&id_cover=<?php echo  $data['id_cover']; ?>');"><button class="btn btn-outline btn-danger btn-xs" title="Hapus"><i class="mdi mdi-delete-forever "></i></button></a>
</td></tr>
<?php $no++;}?>
</table>
</div>
</div>
</div>
</div>
	<!--END PAGE CONTENT -->

 <!-- Modal Popup untuk delete--> 
<div class="modal fade" id="modal_delete">
  <div class="modal-dialog">
    <div class="modal-content" style="margin-top:100px;">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" style="text-align:center;">Anda yakin akan menghapus data ini.. ?</h4>
      </div>
                
      <div class="modal-footer" style="margin:0px; border-top:0px; text-align:center;">
        <a href="#" class="btn btn-danger btn-sm" id="delete_link">Hapus</a>
        <button type="button" class="btn btn-success btn-sm" data-dismiss="modal">Cancel</button>
      </div>
    </div>
  </div>
</div>

<!-- Javascript untuk popup modal Delete--> 
<script type="text/javascript">
    function confirm_modal(delete_url)
    {
      $('#modal_delete').modal('show', {backdrop: 'static'});
      document.getElementById('delete_link').setAttribute('href' , delete_url);
    }
</script>      

