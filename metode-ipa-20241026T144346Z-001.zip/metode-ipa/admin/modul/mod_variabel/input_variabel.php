<div class="sub-heard-part">
<ol class="breadcrumb m-b-0">
<li><a href="media.php">Home</a></li>
<li><a href="?module=variabel">Tabel Data</a></li>
</ol>
</div>
<!--/sub-heard-part-->	
<!--/forms-->
<div class='card-box'>
<div class='row'>
<div class='col-sm-12 col-xs-12 col-md-12'>
<div id='p-20'>

<?php
if(isset($_POST['simpan'])){
	$id_dimensi 	= $_POST['id_dimensi'];
	$pertanyaan	= $_POST['pertanyaan']; 
	$tgl_input= date('Y-m-d H:i:s');
$cek = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM variabel WHERE pertanyaan='$pertanyaan'");
if(mysqli_num_rows($cek) == 0){	
$masuk = mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO variabel(id_dimensi,pertanyaan,tgl_input) VALUES('$id_dimensi','$pertanyaan','$tgl_input')");
if ($masuk) {
	echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Data Berhasil Di Simpan.</div>';
	echo "<meta http-equiv='refresh' content='2; url=?module=variabel'>";
} else {
	echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Data Gagal Di simpan !</div>';
}
} else {
echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Cek Kembali Isian.., Data Sudah Ada,..!</div>';
}
}
			
//Proses edit
$id_variabel=$_GET['id_variabel'];
$sql="select * from variabel where id_variabel='$id_variabel'";
$query=mysqli_query($GLOBALS["___mysqli_ston"], $sql);
$r=mysqli_fetch_array($query);
if(isset($_POST['Edit'])){
	$id_dimensi 	= $_POST['id_dimensi'];
	$pertanyaan	= $_POST['pertanyaan']; 
	$tgl_input= date('Y-m-d H:i:s');
$a=mysqli_query($GLOBALS["___mysqli_ston"], "UPDATE variabel SET pertanyaan = '$_POST[pertanyaan]', id_dimensi = '$_POST[id_dimensi]', tgl_input = '$tgl_input' WHERE id_variabel='$id_variabel'");
if($a){
echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Data Berhasil Di Simpan.</div>';
}else{
echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Data Gagal Di simpan !</div>';
}
echo "<meta http-equiv='refresh' content='2; url=?module=variabel'>";
}
?>

<form action="" method="post" enctype="multipart/form-data" class="form-horizontal">
 
<div class="form-group row">
<label class="col-sm-2 control-label">Dimensi</label>
<div class="col-sm-4">
<select  class='form-control' name='id_dimensi'>
<?php
		  $sql = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM dimensi");
		  while($data = mysqli_fetch_array($sql)){
			if($r['id_dimensi'] == $data['id_dimensi']){
				echo "<option value='$data[id_dimensi]' selected>$data[nama_dimensi]</option>";
			}
			else{
				echo "<option value='$data[id_dimensi]'>$data[nama_dimensi]</option>";
			}
		  }
?>
</select>
</div>
</div>
<div class="form-group row">
<label class="col-sm-2 control-label">Nama Variabel</label>
<div class="col-sm-8">
<input name="pertanyaan" value="<?php echo $r['pertanyaan']; ?>" class="form-control" required="" data-errormessage-value-missing="isian masih kosong" />
</div>
</div>
<div class="form-group row">
<div class="col-sm-2">
<?php if(!$_GET['id_variabel']){
		//bila mau tambah data yang tampil tombol simpan
		echo "<input name=\"simpan\" class=\"btn btn-success\" type=\"submit\" id=\"simpan\" value=\"Simpan\" />&nbsp;";
		echo "<input name=\"batal\" class=\"btn btn-danger\" type=\"button\" id=\"batal\" value=\"Batal\" onclick=\"window.location.href='?module=variabel'\" />";
        } else {
		//Apabila mau edit yg tampil tombol edit dan hapus
		echo "<input name=\"Edit\" class=\"btn btn-success\" type=\"submit\" id=\"edit\" value=\"Simpan\" />&nbsp;";
		echo "<input name=\"batal\" class=\"btn btn-danger\" type=\"button\" id=\"batal\" value=\"Batal\" onclick=\"window.location.href='?module=variabel'\" />";
}
 ?>
</div>
</div>

</form>
 	<!---->
</div>
</div>
</div></div>
<!--//grid-->
