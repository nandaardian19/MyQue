<?php
include "../../../include/koneksi.php";
$id_variabel=$_GET['id_variabel'];
$modal = mysqli_query($GLOBALS["___mysqli_ston"], "DELETE FROM variabel WHERE id_variabel='$id_variabel'");
if($modal){
echo '<script>window.alert("Data Berhasil di Hapus");
       window.location=("../../media.php?module=variabel")</script>';  
	}
?>