<!--sub-heard-part-->
<div class="sub-heard-part">
<ol class="breadcrumb m-b-0">
<li><a href="media.php">Home</a></li>
<li class="active">Table</li>
</ol>
</div>

<!--//sub-heard-part-->
<div class="row">
<div class="col-lg-12">
<div class="panel panel-primary">
<div class="panel-heading"> Data variabel</div>
<div class="panel-body">
<div class="table-responsive">
<a href="?module=input_variabel"><button class="btn btn-sm btn-success"><i class="fa fa-plus"></i> Tambah Data</button></a>
<!-- tables -->
<table class="table m-0 table-colored table-info table-striped table-bordered table-hover" id="datatable">
<thead>
<tr>
<th width="30"><b>No.</b></th>
<th><b>Dimensi</b></th>
<th><b>Variabel</b></th>
<th width="140"><b>Aksi</b></th>
</tr>
</thead>
   <tr>                            
<?php
$tampil = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM variabel a,dimensi b WHERE a.id_dimensi=b.id_dimensi order by a.id_dimensi asc");
$no=1;
while($data=mysqli_fetch_array($tampil)){
echo "
<td><center>$no</center></td>
<td>$data[nama_dimensi]</td>
<td>$data[pertanyaan]</td>";
?>
<td><a href="?module=input_variabel&id_variabel=<?php echo  $data['id_variabel']; ?>"><button class="btn-sm btn btn-success" id="tooltip-hover" title="Edit Data"><i class="mdi mdi-table-edit"></i></button></a>
<a href="#" onclick="confirm_modal('modul/mod_variabel/hapus.php?&id_variabel=<?php echo  $data['id_variabel']; ?>');"><button class="btn-sm btn btn-danger" id="tooltip-animation" title="Hapus Data"><i class="mdi mdi-backspace"></i></button></a>
</td></tr>
<?php $no++;}?>
</table>

</div></div>
</div></div></div>

	<!--END PAGE CONTENT -->

 <!-- Modal Popup untuk delete--> 
<div class="modal fade" id="modal_delete">
  <div class="modal-dialog">
    <div class="modal-content" style="margin-top:100px;">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" style="text-align:center;">Anda yakin akan menghapus data ini.. ?</h4>
      </div>
                
      <div class="modal-footer" style="margin:0px; border-top:0px; text-align:center;">
        <a href="#" class="btn btn-danger btn-sm" id="delete_link">Hapus</a>
        <button type="button" class="btn btn-success btn-sm" data-dismiss="modal">Cancel</button>
      </div>
    </div>
  </div>
</div>

<!-- Javascript untuk popup modal Delete--> 
<script type="text/javascript">
    function confirm_modal(delete_url)
    {
      $('#modal_delete').modal('show', {backdrop: 'static'});
      document.getElementById('delete_link').setAttribute('href' , delete_url);
    }
</script>      

