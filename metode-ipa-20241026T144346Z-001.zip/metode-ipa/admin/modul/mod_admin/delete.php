<?php
include "../../include/koneksi.php";
$id_survey=$_GET['id_survey'];
$modal=mysqli_query($GLOBALS["___mysqli_ston"], "Delete FROM survey WHERE id_survey='$id_survey'");
if($modal){
echo '<script>window.alert("Data Berhasil di Hapus");
       window.location=("../../media.php?module=member")</script>';  
	}
?>