<!--/sub-heard-part-->
<div class="sub-heard-part">
<ol class="breadcrumb m-b-0">
<li><a href="media.php">Home</a></li>
<li><a href="?module=admin">Tabel Data</a></li>
<li class="active">Form Input</li>
</ol>
</div>	
<!--/sub-heard-part-->	
<!--/forms-->
<div class='card-box'>
<div class='row'>
<div class='col-sm-12 col-xs-12 col-md-12'>
<div id='p-20'>
<!---->
<?php
if(isset($_POST['simpan'])){
	$nama=$_POST['nama'];
	$alamat=$_POST['alamat'];
$email=$_POST['email'];
$telepon=$_POST['telepon'];
	$username=$_POST['username'];
	$password=md5($_POST['password']);
$foto=$_FILES['foto']['name'];
$akses=$_POST['akses'];
 if(strlen($foto)>0){ 
 
 	if(is_uploaded_file($_FILES['foto']['tmp_name'])){
	move_uploaded_file($_FILES['foto']['tmp_name'],"foto_admin/".$foto);
	}
}
  $cek = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM user_admin WHERE username='$username' AND email='$email'");
  if(mysqli_num_rows($cek) == 0){	
$a=mysqli_query($GLOBALS["___mysqli_ston"], "insert into user_admin values('','$nama','$alamat','$email','$telepon','$username','$password','$foto','$akses')");
if($a){
echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Data Berhasil Di Simpan.</div>';
						}else{
echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Ups, Data Gagal Di simpan !</div>';
						}
				}else{
echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Cek Kembali Isian.., Data Sudah Ada,..!</div>';
				}
			}
			
//Proses edit
$id_admin=$_GET['id_admin'];
$sql="select * from user_admin where id_admin='$id_admin'";
$query=mysqli_query($GLOBALS["___mysqli_ston"], $sql);
$r=mysqli_fetch_array($query);
if(isset($_POST['Edit'])){
$nama=$_POST['nama'];
$alamat=$_POST['alamat'];
$email=$_POST['email'];
$telepon=$_POST['telepon'];
$username=$_POST['username'];
$password=md5($_POST['password']);
$foto=$_FILES['foto']['name'];
$akses=$_POST['akses'];
 if(strlen($foto)>0){ 
 unlink("foto_admin/$r[foto]"); 
 	if(is_uploaded_file($_FILES['foto']['tmp_name'])){
	move_uploaded_file($_FILES['foto']['tmp_name'],"foto_admin/".$foto);
	}
$modal=mysqli_query($GLOBALS["___mysqli_ston"], "update user_admin set foto='$foto' where id_admin='$id_admin'");
}
if (!empty($_POST['password'])){
$password = md5($_POST['password']);
$a=mysqli_query($GLOBALS["___mysqli_ston"], "UPDATE user_admin SET nama='$nama',alamat='$alamat',email='$email',telepon='$telepon',username='$username',password='$password',akses='$akses' WHERE id_admin='$id_admin'");
if($a){
echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Data Berhasil Di Update.</div>';
echo "<meta http-equiv='refresh' content='2; url=?module=admin'>";
}
 }else{
$a=mysqli_query($GLOBALS["___mysqli_ston"], "UPDATE user_admin SET nama='$nama',alamat='$alamat',email='$email',telepon='$telepon',akses='$akses' WHERE id_admin='$id_admin'");
if($a){
echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Data Berhasil Di Update.</div>';
echo "<meta http-equiv='refresh' content='2; url=?module=admin'>";
}
}
}
?>
<form action="" method="post" enctype="multipart/form-data" class="form-horizontal">
	<div class="form-group">
	<label class="control-label col-lg2 col-lg-2">Nama Lengkap</label>
	<div class="col-lg-6">
              <input id="nama" name="nama" type="text" class='form-control' required='' data-errormessage-value-missing='isian masih kosong' value="<?php echo $r['nama']; ?>" />
     </div> </div>
     <div class="form-group">
	<label class="control-label col-lg2 col-lg-2">Alamat Lengkap</label>
	<div class="col-lg-8">
              <input id="alamat" name="alamat" type="text" class='form-control' required='' data-errormessage-value-missing='isian masih kosong' value="<?php echo $r['alamat']; ?>" />
     </div> </div>
     
     	<div class="form-group">
	<label class="control-label col-lg2 col-lg-2">Email</label>
	<div class="col-lg-6">
              <input id="email" name="email" type="text" class='form-control' required='' data-errormessage-value-missing='isian masih kosong' value="<?php echo $r['email']; ?>" />
     </div> </div>
     
     	<div class="form-group">
	<label class="control-label col-lg2 col-lg-2">Telepon</label>
	<div class="col-lg-4">
              <input id="telepon" name="telepon" type="text" class='form-control' required='' data-errormessage-value-missing='isian masih kosong' value="<?php echo $r['telepon']; ?>" />
     </div> </div>
     
	<div class="form-group">
	<label class="control-label col-lg2 col-lg-2">Username</label>
	<div class="col-lg-4">
    <input id="username" name="username" type="text" placeholder="Username" class='form-control' required='' data-errormessage-value-missing='isian masih kosong' value="<?php echo $r['username']; ?>" />
            </div>
             </div>        		

	<div class="form-group">
	<label class="control-label col-lg2 col-lg-2">Password</label>
	<div class="col-lg-4">
              <input id="password" name="password" type="password" placeholder="Password" class="form-control"/>
              <?php
if($_GET['id_admin']){
echo "<br><font color='red'>Apabila password tidak diubah, silahkan dikosongkan saja</font>";
}
?>
</div>
</div>

<div class="form-group">
<label class="control-label col-lg2 col-lg-2">Hak Akses</label>
<div class="col-lg-2">
<select name="akses" id="akses"  class="form-control">
<?php
	$arakses = array(
	'1' => "Administrator",
	'2' => "Member"
	);
foreach ($arakses as $db => $isi) {
if ($r['akses']==$db){
echo "<option value='$db' selected>$isi</option>";
	}else{
echo "<option value='$db'>$isi</option>";
	}
	}
?>
</select>
</div>
 </div>
            
	<div class="form-group">
	<label class="control-label col-lg2 col-lg-2">Foto</label>
	<div class="col-lg-4">
 <?php if($_GET['id_admin']){
				//tampilkan foto saat mau ngedit
				 echo "<img src='foto_admin/$r[foto]' width=110 height=110> <br />";
				} 
				?>
				  <input name="foto" type="file" id="foto" />
</div>    
</div>

<div style="text-align:left" class="form-actions no-margin-bottom">
<?php if(!$_GET['id_admin']){
		//bila mau tambah data yang tampil tombol simpan
		echo "<input name=\"simpan\" class=\"btn btn-success btn-sm btn-grad btn-rect\" type=\"submit\" id=\"simpan\" value=\"Simpan\" />&nbsp;";
		echo "<input name=\"batal\" class=\"btn btn-warning btn-sm btn-grad btn-rect\" type=\"reset\" id=\"batal\" value=\"Batal\" />";
        } else {
		//Apabila mau edit yg tampil tombol edit dan hapus
		echo "<input name=\"Edit\" class=\"btn btn-primary btn-sm btn-grad btn-rect\" type=\"submit\" id=\"edit\" value=\"Simpan\" />&nbsp;";
		echo "<input name=\"batal\" class=\"btn btn-warning btn-sm btn-grad btn-rect\" type=\"reset\" id=\"batal\" value=\"Batal\" />";
} ?>

</div>
</form>
 	<!---->
 </div>
</div>
</div></div>
<!--//grid-->