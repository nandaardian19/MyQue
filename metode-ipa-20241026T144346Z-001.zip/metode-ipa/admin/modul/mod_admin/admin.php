<!--sub-heard-part-->
<div class="sub-heard-part">
<ol class="breadcrumb m-b-0">
<li><a href="media.php">Home</a></li>
<li class="active">Tables</li>
<li><a href="?module=input_admin">Entry Data User Baru</a></li>
</ol>
</div>
<!--//sub-heard-part-->

<div class="row">
<div class="col-lg-12">
<div class="panel panel-default">
<div class="panel-heading"> Tabel Data User</div>
<div class="panel-body">
<div class="table-responsive">
<!-- tables -->
<table class="table table-striped table-bordered table-hover" id="datatable">
<thead>
<tr>
<th width="10"><b>No.</b></th>
<th><b>Nama User </b></th>
<th><b>Alamat </b></th>
<th><b>Kontak </b></th>
<th><b>Username</b></th>
<th><b>Hak Akses</b></th>
<th><b><div align="center">Foto</div></b></th>
<th width="50"><b><div align="center">Aksi</div></b></th>
</tr>
</thead>
                                      
                                       <?php
$view=mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM user_admin");
$no=1;
		while($data=mysqli_fetch_array($view)){
				  ?>

			<tr>
            	      <?php
	      $lvl = $data['akses'];
	      $tp = array(
	      	'1'=>'Administrator',
			'2'=>'Member');
	      echo "
	      <td class='center'>$no</td>
	      <td>$data[nama]</td>
		   <td>$data[alamat]</td>
		    <td>$data[telepon] / $data[email]</td>
	      <td>$data[username]</td>
	      <td>$tp[$lvl]</td>";
           ?>     
<td><center>
 <?php
$foto=$data['foto'];
if(empty($foto)){
?>
<img src="foto_admin/user.PNG" class="thumb-sm img-circle" />
<?php
					}
					else{
					?>
<img src="foto_admin/<?php echo $data['foto']; ?>"  class="thumb-sm img-circle" />
<?php
}
?>
</center>
</td>
<td>
<a href="?module=input_admin&id_admin=<?php echo  $data['id_admin']; ?>"><button class="btn btn-outline btn-success btn-xs" title="Edit"><i class="mdi mdi-table-edit"></i></button></a>
<a href="#" onclick="confirm_modal('modul/mod_admin/hapus.php?&id_admin=<?php echo  $data['id_admin']; ?>');"><button class="btn btn-outline btn-danger btn-xs" title="Hapus"><i class="fa fa-trash"></i></button></a>
</td></tr>
             <?php $no++;}?>
</table>
</div>
</div>
</div></div>
	<!--END PAGE CONTENT -->

 <!-- Modal Popup untuk delete--> 
<div class="modal fade" id="modal_delete">
  <div class="modal-dialog">
    <div class="modal-content" style="margin-top:100px;">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" style="text-align:center;">Anda yakin akan menghapus data ini.. ?</h4>
      </div>
                
      <div class="modal-footer" style="margin:0px; border-top:0px; text-align:center;">
        <a href="#" class="btn btn-danger btn-sm" id="delete_link">Hapus</a>
        <button type="button" class="btn btn-success btn-sm" data-dismiss="modal">Cancel</button>
      </div>
    </div>
  </div>
</div>

<!-- Javascript untuk popup modal Delete--> 
<script type="text/javascript">
    function confirm_modal(delete_url)
    {
      $('#modal_delete').modal('show', {backdrop: 'static'});
      document.getElementById('delete_link').setAttribute('href' , delete_url);
    }
</script>      

