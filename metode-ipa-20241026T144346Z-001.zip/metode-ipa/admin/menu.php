
<div class="user-details">
                            <div class="overlay"></div>
                            <div class="text-center">
<?php
$foto=$ran['foto'];
if(empty($foto)){
?>
<img src="foto_admin/default.png" alt="user-img" class="thumb-md img-circle">
<?php
} else{
?>
<img src="<?php echo "foto_admin/".$foto; ?>" alt="user-img" class="thumb-md img-circle">
<?php } ?>
                            </div>
                            <div class="user-info">
                                <div>
                                    <a href="#setting-dropdown" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><?php echo $ran['nama']; ?> <span class="mdi mdi-menu-down"></span></a>
                                </div>
                            </div>
                        </div>

                        <div class="dropdown" id="setting-dropdown">
                            <ul class="dropdown-menu">
                                <li><a href="?module=user&id=<?php echo $ran['id_admin'];?>"><i class="mdi mdi-face-profile m-r-5"></i> Profile</a></li>
                                <li><a href="?module=update_user&id_admin=<?php echo $ran['id_admin'];?>"><i class="mdi mdi-account-settings-variant m-r-5"></i> Settings</a></li>
                                <li><a href="logout.php"><i class="mdi mdi-logout m-r-5"></i> Logout</a></li>
                            </ul>
                        </div>
     
 <!-- end admin-->
                        <ul>
                        	<li class="menu-title">Navigation</li>

                            <li class="has_sub">
                                <a href="media.php" class="waves-effect"><i class="mdi mdi-view-dashboard"></i> <span> Dashboard </span> </a>
                            </li>
                            
<?php if($akses=='1'){ ?> 


                            <li class="has_sub">
<a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-layers"></i><span> Kuisioner</span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
<li><a href="?module=variabel"> Variabel </a></li>
<li><a href="?module=dimensi"> Dimensi </a></li>
                                </ul>
                            </li>
<li><a href="?module=hasil" class="waves-effect"><i class="mdi mdi-code-not-equal"></i><span>Analisis IPA </span></a> </li>
<li><a href="?module=cover" class="waves-effect"><i class="mdi mdi-newspaper"></i><span>Setting Web </span></a> </li>
                            <li class="has_sub">
<a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-account-settings-variant"></i><span> Manajemen User</span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
<li><a href="?module=admin">Admin</a></li>
<li><a href="?module=member">Member</a></li>
                                </ul>
                            </li>            
<?php } ?>
 <!-- end admin-->
<?php if($akses=='2'){ ?>
<li><a href="?module=survey" class="waves-effect"><i class="mdi mdi-tooltip-edit"></i><span>Input Kuisioner</span></a> </li>
<?php } ?>
 <!-- end warga-->
</ul>