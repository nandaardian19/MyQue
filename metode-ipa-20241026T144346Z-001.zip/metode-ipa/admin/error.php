<!DOCTYPE html>
<html class="account-pages-bg">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="A fully featured admin theme which can be used to build CRM, CMS, etc.">
        <meta name="author" content="Coderthemes">

        <!-- App favicon -->
       <link rel="shortcut icon" href="assets/images/error.png">

        <title>Error...!</title>

        <!-- App css -->
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/pages.css" rel="stylesheet" type="text/css" />

    </head>


    <body class="bg-transparent">

        <!-- HOME -->
        <section>
            <div class="container-alt">
                <div class="row">
                    <div class="col-sm-12 text-center">

                        <div class="wrapper-page">
                            <img src="assets/images/animat-search-color.gif" alt="" height="120">
                            <h2 class="text-uppercase text-danger">Halaman, Tidak Tampil</h2>
                            <p class="text-muted"> Mohon maaf,,, untuk menampilkan halaman admin atau halaman akun anda, Silahkan Login Terlebih Dahulu...</p>

                            <a class="btn btn-success waves-effect waves-light m-t-20" href="../index.php"> Return Home</a>
                        </div>

                    </div>
                </div>
            </div>
          </section>
          <!-- END HOME -->

    </body>
</html>