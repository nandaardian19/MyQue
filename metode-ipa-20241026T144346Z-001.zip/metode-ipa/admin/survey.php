<?php
error_reporting(0);
?>
<?php
error_reporting(E_ALL^(E_NOTICE));
session_start();
$akses=$_SESSION['akses'];
$id_admin=$ran['id_admin'];
$nama=$ran['nama'];
$alamat=$ran['alamat'];
$email=$ran['email'];
$telepon=$ran['telepon'];

?>
<!--/sub-heard-part-->
<div class="sub-heard-part">
<ol class="breadcrumb m-b-0">
<li><a href="media.php">Home</a></li>
<li class="active">Survey Kepuasan Pelayanan </li>
</ol>
</div>	
<!--/sub-heard-part-->

 <?php
if(isset($_POST['input'])){
$id_admin=$_POST['id_admin'];
$nama=$_POST['nama'];
$alamat=$_POST['alamat'];
$email=$_POST['email'];
$telepon=$_POST['telepon'];
$isi_pesan=$_POST['isi_pesan'];
$date=date('Y-m-d');
$id_survey = date('Ymd his');

$no_hitung = 1;
$sql_hitung = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM dimensi");
while($data_hitung = mysqli_fetch_array($sql_hitung)){
	$id_hitung = $data_hitung['id_dimensi'];		
	$hasil_hitung = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM variabel, dimensi WHERE variabel.id_dimensi = '$id_hitung' AND variabel.id_dimensi = dimensi.id_dimensi ORDER BY dimensi.id_dimensi");
	$i_hitung = 1;
	while ($r_hitung = mysqli_fetch_array($hasil_hitung)){
		$id_hitung = $data_hitung['id_dimensi'];
		$aqila_hitung = $_POST['aqila'.$i_hitung.$id_hitung];
		$adiva_hitung = $_POST['adiva'.$i_hitung.$id_hitung];
		$i_hitung++;
	}
	echo "<br>";
	$no_hitung++;
}
	$cek = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM survey WHERE id_admin='$id_admin' AND MONTH(dateSurvey)=MONTH(NOW())");
				if(mysqli_num_rows($cek) == 0){	
	$no = 1;
	$sql = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM dimensi");
	$a=mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO survey(id_survey,id_admin,nama,alamat,email,telepon,dateSurvey,isi_pesan)
	VALUES('$id_survey','$id_admin','$nama','$alamat','$email','$telepon','$date','$isi_pesan')");
	while($data = mysqli_fetch_array($sql)){
		$id = $data['id_dimensi'];		
		$hasil = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM variabel, dimensi WHERE variabel.id_dimensi = '$id' AND variabel.id_dimensi = dimensi.id_dimensi ORDER BY dimensi.id_dimensi");
		$i = 1;
		while ($r = mysqli_fetch_array($hasil)){
			$id = $data['id_dimensi'];
			$aqila = $_POST['aqila'.$i.$id];
			$adiva = $_POST['adiva'.$i.$id];
			// echo "$i $aqila<br>";
			if ($aqila == '5'){
mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO nilai_variabel (id_variabel,id_dimensi,id_survey,nilai_kinerja,skala1,skala2,skala3,skala4,skala5) 
				VALUES('$r[id_variabel]','$r[id_dimensi]','$id_survey','$aqila','5','0','0','0','0')");
			}	
			elseif($aqila == '4'){
mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO nilai_variabel (id_variabel,id_dimensi,id_survey,nilai_kinerja,skala1,skala2,skala3,skala4,skala5) 
				VALUES('$r[id_variabel]','$r[id_dimensi]','$id_survey','$aqila','0','4','0','0','0')");
			}
			elseif($aqila == '3'){
mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO nilai_variabel (id_variabel,id_dimensi,id_survey,nilai_kinerja,skala1,skala2,skala3,skala4,skala5) 
				VALUES('$r[id_variabel]','$r[id_dimensi]','$id_survey','$aqila','0','0','3','0','0')");
			}
			elseif($aqila == '2'){
mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO nilai_variabel (id_variabel,id_dimensi,id_survey,nilai_kinerja,skala1,skala2,skala3,skala4,skala5) 
				VALUES('$r[id_variabel]','$r[id_dimensi]','$id_survey','$aqila','0','0','0','2','0')");
			}
			elseif($aqila == '1'){
mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO nilai_variabel (id_variabel,id_dimensi,id_survey,nilai_kinerja,skala1,skala2,skala3,skala4,skala5) 
				VALUES('$r[id_variabel]','$r[id_dimensi]','$id_survey','$aqila','0','0','0','0','1')");
			}
			if ($adiva == '5'){
mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO nilai_harapan (id_variabel,id_dimensi,id_survey,nilai_harapan,h1,h2,h3,h4,h5) 
				VALUES('$r[id_variabel]','$r[id_dimensi]','$id_survey','$adiva','5','0','0','0','0')");
			}	
			elseif($adiva == '4'){
mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO nilai_harapan (id_variabel,id_dimensi,id_survey,nilai_harapan,h1,h2,h3,h4,h5) 
				VALUES('$r[id_variabel]','$r[id_dimensi]','$id_survey','$adiva','0','4','0','0','0')");
			}
			elseif($adiva == '3'){
mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO nilai_harapan (id_variabel,id_dimensi,id_survey,nilai_harapan,h1,h2,h3,h4,h5) 
				VALUES('$r[id_variabel]','$r[id_dimensi]','$id_survey','$adiva','0','0','3','0','0')");
			}
			elseif($adiva == '2'){
mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO nilai_harapan (id_variabel,id_dimensi,id_survey,nilai_harapan,h1,h2,h3,h4,h5) 
				VALUES('$r[id_variabel]','$r[id_dimensi]','$id_survey','$adiva','0','0','0','2','0')");
			}
			elseif($adiva == '1'){
mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO nilai_harapan (id_variabel,id_dimensi,id_survey,nilai_harapan,h1,h2,h3,h4,h5) 
				VALUES('$r[id_variabel]','$r[id_dimensi]','$id_survey','$adiva','0','0','0','0','1')");
			}
			$i++;
		}
		$no++;
	}
if($a){
echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Data Berhasil Di Simpan.!<br>
Terima kasih untuk melengkapi pertanyaan yang kami sediakan. Pendapat Anda sangat berarti bagi kami untuk meningkatkan pelayanan. </div>';
						}else{
echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Data Gagal Di simpan !</div>';
						}
				}else{
echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Mohon Maaf..!! Survey dilakukan 1 (satu) bulan 1 x,..!<br>
Terima kasih. </div>';
				}
	echo "<meta http-equiv='refresh' content='3; url=media.php'>";
}
?> 
<!--/forms-->
<div class="card-box">
<div class='row'>
<div class='col-sm-12'>
<div class="demo-box">
<form action="" method="post" enctype="multipart/form-data" name="popup-validation" id="popup-validation" class="form-horizontal">
<div class="form-group">
<label class="control-label col-lg-4">Nama Responden</label>
<div class="col-lg-4">
<input type='text' name='nama' class="form-control" value="<?php echo $nama;?>" readonly="readonly">
</div></div>
<div class="form-group">
<label class="control-label col-lg-4">Alamat</label>
<div class="col-lg-6">
<input type='text' name='alamat' class="form-control" value="<?php echo $alamat;?>" readonly="readonly">
</div></div>
<div class="form-group">
<label class="control-label col-lg-4">Email</label>
<div class="col-lg-4">
<input type='text' name='email' class="form-control" value="<?php echo $email;?>" readonly="readonly">
</div></div>
<div class="form-group">
<label class="control-label col-lg-4">No. Telepon</label>
<div class="col-lg-2">
<input type='text' name='telepon' class="form-control" value="<?php echo $telepon;?>" readonly="readonly">
</div></div>

<input name='id_admin' id='id_admin' type='hidden' value="<?php echo $id_admin;?>">
	<tr>
		<td width="100%" valign="top" colspan="5" style="border-style: none; border-width: medium">
		<font face="Century Gothic" size="2"><strong>Silahkan memberikan 
		survey atas pelayanan yang kami lakukan, dimana hal ini sangat bermanfaat 
		untuk melakukan analisis agar meningkatkan kualitas layanan di Perusahaan Kami</strong><br>
		<i>Silahkan diisi dengan tanda </i></font>
		<span style="line-height: 115%; font-family: Century Gothic; font-style: italic">
		<font size="2">&#8730; pada &#9633; serta keterangan sesuai dengan penilaian Anda 
		pada kolom yang telah disediakan</font></span></td>
	</tr>
	<tr><div id="print">
		<table class="table table-striped table-bordered table-hover table-colored-bordered table-bordered-info" >
			<tr>
				<th colspan='3'>&nbsp;</th>
<th colspan='5' class="warning"><p align='center'><b><font face='Century Gothic' size='3'>Nilai Kinerja</font></b></th>
<th colspan='5' class="info"><p align='center'><b><font face='Century Gothic' size='3'>Nilai Harapan</font></b></th>
			</tr>
			<tr>
            
				<th>No.</th>
				<th colspan='2'><center><font face='Century Gothic' size='3'> Variabel </font></center></th>	
				<th class="th1"><center><font face='Century Gothic' size='2'>Sangat Setuju</font></center></th>
				<th class="th1"><center><font face='Century Gothic' size='2'>Setuju</font></center></th>
				<th class="th1"><center><font face='Century Gothic' size='2'>Netral</font></center></th>
				<th class="th1"><center><font face='Century Gothic' size='2'>Tidak Setuju</font></center></th>
				<th class="th1"><center><font face='Century Gothic' size='2'>Sangat Tidak Setuju</font></center></th>
                
				<th class="th1"><center><font face='Century Gothic' size='2'>Sangat Setuju</font></center></th>
				<th class="th1"><center><font face='Century Gothic' size='2'>Setuju</font></center></th>
				<th class="th1"><center><font face='Century Gothic' size='2'>Netral</font></center></th>
				<th class="th1"><center><font face='Century Gothic' size='2'>Tidak Setuju</font></center></th>
				<th class="th1"><center><font face='Century Gothic' size='2'>Sangat Tidak Setuju</font></center></th>
              
			</tr>
		
			<?php

			$no = 1;
			$sql = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM dimensi");
			while($data = mysqli_fetch_array($sql)){
				$id = $data['id_dimensi'];
				echo "<tr valign='top'>
						<th><font face='Century Gothic' size='2'>($no)</font></th>
						<th colspan='2' class='table-colored-full table-full-inverse'><font face='Century Gothic' size='2'>$data[nama_dimensi]</font></th>
						<td class='table-colored-full table-full-inverse' colspan='10'></td>
					</tr>";
					
$hasil = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM variabel, dimensi WHERE variabel.id_dimensi = '$id' AND variabel.id_dimensi = dimensi.id_dimensi ORDER BY dimensi.id_dimensi");
				$i = 1;
				while ($r = mysqli_fetch_array($hasil)){
				
					echo "<tr>
							<td> </td>
							<td>$i </td>
							<td><font face='Century Gothic' size='2'>$r[pertanyaan]</font></td>
<td align='center' class='warning'> <input type='radio' name='aqila$i$data[id_dimensi]' value='5' required=''> </td>
<td align='center' class='warning'> <input type='radio' name='aqila$i$data[id_dimensi]' value='4' required=''> </td>
<td align='center' class='warning'> <input type='radio' name='aqila$i$data[id_dimensi]' value='3' required=''> </td>
<td align='center' class='warning'> <input type='radio' name='aqila$i$data[id_dimensi]' value='2' required=''> </td>
<td align='center' class='warning'> <input type='radio' name='aqila$i$data[id_dimensi]' value='1' required=''> </td>
				
<td align='center' class='info'> <input type='radio' name='adiva$i$data[id_dimensi]' value='5' required=''> </td>
<td align='center' class='info'> <input type='radio' name='adiva$i$data[id_dimensi]' value='4' required=''> </td>
<td align='center' class='info'> <input type='radio' name='adiva$i$data[id_dimensi]' value='3' required=''> </td>
<td align='center' class='info'> <input type='radio' name='adiva$i$data[id_dimensi]' value='2' required=''> </td>
<td align='center' class='info'> <input type='radio' name='adiva$i$data[id_dimensi]' value='1' required=''> </td>
							</tr>";
					$i++;
				}
				echo "<br>";
				$no++;
			}
			?>
		</table> 
</div>
	</td>
	</tr>
    <table>
   
	<tr>
		<td width="81%" valign="top" style="border-style: none; border-width: medium" height="21" colspan="5">
		<b><font face="Century Gothic" size="2">* NB:</font></b></td>
	</tr>	
	<tr>
		<td width="81%" valign="top" style="border-style: none; border-width: medium" height="21" colspan="5">
		<b><font face="Century Gothic" size="2">
		Silahkan Masukan Kritik / Saran Untuk Bahan Analisa dan Evaluasi Pelayanan Kami..</font></b></td>
	</tr>
	<tr>
		<td width="81%" valign="bottom" style="border-style: none; border-width: medium" height="15" colspan="5"><textarea name='isi_pesan' cols='70' rows='2' placeholder="Masukan Kritik dan Saran Anda...." class="validate[required] form-control"></textarea></td>
	</tr>
	<tr>
		<td width="38%" valign="top" style="border-style: none; border-width: medium" height="46" rowspan="2">&nbsp;</td>
	</tr>
	<tr>
		<td width="21%" valign="top" style="border-style: none; border-width: medium" height="23">&nbsp;</td>
	</tr>
	<tr>
<td width="1%" style="border-style: none; border-width: medium" height="19"><button class="btn btn-sm btn-primary" type="submit" name="input" id="input">
                      Simpan
                  </button></td>
		<td width="29%" style="border-style: none; border-width: medium" height="19">&nbsp;</td>
	</tr>
	<tr>
		<td width="38%" valign="top" style="border-style: none; border-width: medium" height="19">&nbsp;</td>
	</tr>
	<tr>
		<td width="99%" valign="top" style="border-style: none; border-width: medium" height="19" colspan="5" align="center">
		<b><font face="Century Gothic" size="2">Terima kasih atas partisipasi Anda dalam 
		mengisi pertanyaan kami, Untuk Perbaikan Pelayanan</font></b></td>
	</tr>
</table>

</form>
</div></div></div></div>