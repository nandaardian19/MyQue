<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Login | Member</title>
    <link rel="shortcut icon" href="assets/images/lg.png">
	<!-- Mobile Specific Metas -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<!-- Font-->
	<link rel="stylesheet" type="text/css" href="assets/css/sourcesanspro-font.css">
	<!-- Main Style Css -->
    <link rel="stylesheet" href="assets/css/aq_ad.css"/>
</head>
<body class="form-v8">
<?php
include "../include/koneksi.php";
if(isset($_POST['simpan'])){
			$nama = $_POST['nama'];
			$alamat = $_POST['alamat'];
			$email = $_POST['email'];
			$telepon = $_POST['telepon'];
			$username = $_POST['username'];
			$password=md5($_POST['password']);
			$akses ='2';
			$cek=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "SELECT email FROM user_admin
					   WHERE email='$_POST[email]'"));
			
				 if(strlen(trim($password)) <=7  ) {
					echo '<script language="javascript">
						alert("Password minimal 8 digit!");
						window.location="sig_in.php";
						</script>';
						exit();	}
				else if ($cek > 0){
						echo '<script language="javascript">
						alert("Email Sudah Ada Yang Menggunakan");
						window.location="sig_in.php";
						</script>';
						exit();	}
				else {
$query = mysqli_query($GLOBALS["___mysqli_ston"], "insert into user_admin (nama,alamat,email, telepon, username, password, akses)
		value ('$nama','$alamat','$email','$telepon','$username','$password','$akses')");

		if($query){
			?><script language="javascript">document.location.href="sig_in.php?status=Berhasil Registrasi";</script>
<?php }else{ ?>
<script language="javascript">document.location.href="sig_in.php?status=Gagal Registrasi";</script>
				
<?php
}		
}
}
?>  
	<div class="page-content">
		<div class="form-v8-content">
			<div class="form-left">
            <br> <br>
			<a href="../index.php"><img src="assets/images/logoQ.PNG" alt="form"></a>
			</div>
			<div class="form-right">
<h3 align="center"><?php  if(isset($_GET['status'])){ echo "&laquo; ".$_GET['status']." &raquo;"; }?></h3>
				<div class="tab">
					<div class="tab-inner">
						<button class="tablinks" onclick="openCity(event, 'sign-up')" id="defaultOpen">Login</button>
					</div>
					<div class="tab-inner">
						<button class="tablinks" onclick="openCity(event, 'sign-in')">Registrasi</button>
					</div>
				</div>
				<form class="form-detail" action="cek_login.php" method="post">
					<div class="tabcontent" id="sign-up">
						<div class="form-row">
							<label class="form-row-inner">
                            <input type="text" name="username" class="input-text" autocomplete="off" required="" data-errormessage-value-missing="username masih kosong">
								<span class="label">Username</span>
		  						<span class="border"></span>
							</label>
						</div>
						<div class="form-row">
							<label class="form-row-inner">
                            <input type="password" name="password" class="input-text" required="" data-errormessage-value-missing="password masih kosong">
								<span class="label">Password</span>
								<span class="border"></span>
							</label>
						</div>
						<div class="form-row-last">
						<input type="submit" name="Login" id="Login" class="register" value="Sign In">
						</div>
					</div>
				</form>
                
                
				<form class="form-detail" action="" method="post">
					<div class="tabcontent" id="sign-in">
						<div class="form-row">
							<label class="form-row-inner">
								<input type="text" name="nama" class="input-text" required="" data-errormessage-value-missing="nama masih kosong">
								<span class="label">Nama Lengkap</span>
		  						<span class="border"></span>
							</label>
						</div>
                        	<div class="form-row">
							<label class="form-row-inner">
								<input type="text" name="alamat" class="input-text" required="" data-errormessage-value-missing="alamat masih kosong">
								<span class="label">Alamat</span>
		  						<span class="border"></span>
							</label>
						</div>
						<div class="form-row">
							<label class="form-row-inner">
								 <input type="email" name="email" class="input-text" required="" data-errormessage-value-missing="email masih kosong">
								<span class="label">E-Mail</span>
		  						<span class="border"></span>
							</label>
						</div>
                        	<div class="form-row">
							<label class="form-row-inner">
								<input type="text" name="telepon" class="input-text" maxlength="12" minlength="12" required="" data-errormessage-value-missing="isian nomor telepon masih kosong" onkeypress="return hanyaAngka(event)">
								<span class="label">No. HP</span>
		  						<span class="border"></span>
							</label>
						</div>
                        <div class="form-row">
							<label class="form-row-inner">
                            <input type="text" name="username" class="input-text" autocomplete="off" required="" data-errormessage-value-missing="username masih kosong">
								<span class="label">Username</span>
		  						<span class="border"></span>
							</label>
						</div>
						<div class="form-row">
							<label class="form-row-inner">
							 <input type="password" name="password" autofocus class="input-text" required="" data-errormessage-value-missing="password masih kosong">
								<span class="label">Password</span>
								<span class="border"></span>
							</label>
						</div>
						
						<div class="form-row-last">
							
                     <input type="submit" name="simpan" class="register" value="Register">
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
	<script type="text/javascript">
		function openCity(evt, cityName) {
		    var i, tabcontent, tablinks;
		    tabcontent = document.getElementsByClassName("tabcontent");
		    for (i = 0; i < tabcontent.length; i++) {
		        tabcontent[i].style.display = "none";
		    }
		    tablinks = document.getElementsByClassName("tablinks");
		    for (i = 0; i < tablinks.length; i++) {
		        tablinks[i].className = tablinks[i].className.replace(" active", "");
		    }
		    document.getElementById(cityName).style.display = "block";
		    evt.currentTarget.className += " active";
		}

		// Get the element with id="defaultOpen" and click on it
		document.getElementById("defaultOpen").click();
	</script>
    <script src="assets/js/jquery.js%3bjsessionid=A2BE85636D64DC5AE3405D6B5999BC06"></script>
<script src="assets/js/civem.js%3bjsessionid=A2BE85636D64DC5AE3405D6B5999BC06"></script>
    <script>
		function hanyaAngka(evt) {
		  var charCode = (evt.which) ? evt.which : event.keyCode
		   if (charCode > 31 && (charCode < 48 || charCode > 57))
 
		    return false;
		  return true;
		}
	</script>
</body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>